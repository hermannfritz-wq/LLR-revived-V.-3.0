#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLR-Revival 4.0 - INSTALLER (DEUTSCH)
Zeitstempel: 28.02.2026
Entwickelt von: Pastor Hermann Fritz mit Claude AI (Anthropic)
REVISION v4.0: Lesbarkeit verbessert, Textumbruch optimiert, Hover vergrößert
"""

import sys
import os
import shutil
import platform
import glob
import sqlite3
import json
import zlib
import atexit
import collections
from pathlib import Path

LANG = 'de'
TIMESTAMP = '28.02.2026 11:30'

def pause():
    try:
        input("\n🔵 Drücken Sie ENTER zum Beenden...")
    except:
        pass

atexit.register(pause)

HEADER = """
╔══════════════════════════════════════════════════════════════════╗
║    LLR-REVIVAL 4.0 - INSTALLATION (DEUTSCH)                      ║
║    Kategorisiert Ihre Bücher automatisch in 24 Kategorien        ║
║    Version: 28.02.2026 11:30 (mit Lesbarkeits-Verbesserungen)    ║
╚══════════════════════════════════════════════════════════════════╝
"""

HTML_FILE = 'LLR-Revival-4.0-DE.html'
SHORTCUT_NAME = 'LLR Revival 4.0 DE'

# ============================================================
# KATEGORIEN
# WICHTIG: Die Keys müssen EXAKT mit CATEGORY_TRANSLATIONS in app.js übereinstimmen!
# Gültige Keys: 'Bibel & Bibelwörterbücher', 'Kommentare', 'Kirchengeschichte',
#   'Theologie & Dogmatik', 'Biblische Sprachen', 'Apologetik & Weltanschauung',
#   'Mission & Evangelisation', 'Homiletik & Predigt', 'Hermeneutik & Auslegung',
#   'Seelsorge', 'Andacht & Spiritualität', 'Praktische Theologie', 'Biografien',
#   'Lexika & Wörterbücher', 'Eschatologie', 'Archäologie & Geschichte Israels',
#   'Biblische Theologie', 'Altes Testament', 'Neues Testament', 'Ethik',
#   'I. Journale & Magazine', 'II. Kleine Buch- & Journalreihen', 'Nachschlagewerke',
#   'Early American History', 'Sonstige'
# ============================================================
CATEGORIES = {

    # ── HÖCHSTE PRIORITÄT: Early American History ──────────────────────
    'Early American History': {
        'keywords': [
            # EVANS-IDs Muster (historische amerikanische Dokumente bis ~1820)
            'early american', 'puritan', 'puritans', 'colonial america', 'american colonial',
            'new england', 'new world', 'founding fathers', 'american revolution',
            'cotton mather', 'increase mather', 'jonathan edwards', 'john winthrop',
            'george whitefield', 'library of early american', 'new-england',
            # EVANS-typische Phrasen
            'delivered before', 'delivered to', 'oration delivered', 'sermon delivered',
            'province of', 'inhabitants of', 'colony of', 'general court',
            'boston printed', 'new-york printed', 'philadelphia printed',
            'assembly of', 'excellency', 'his majesties', 'her majesties',
            'continental congress', 'constitutional convention',
            # Amerikanische Geschichte
            'civil war', 'confederate', 'union army', 'gettysburg',
            'photographic history of the civil war', 'southern historical',
            'confederate military', 'reconstruction era',
            # Frühe Baptisten / Quäker / frühe Kirchen Amerika
            'founders journal', 'american presbyterian', 'princeton theological review',
        ],
        'priority': 1000
    },

    # ── I. JOURNALE & MAGAZINE (Series mit >5 Bänden) ────────────────────
    'I. Journale & Magazine': {
        'keywords': [
            'journal of', 'journal for', 'theological journal', 'biblical journal',
            'quarterly journal', 'annual journal', 'bulletin of', 'review of',
            # ALLE wichtigen Journal-Serien:
            'semeia', 'ex auditu', 'evangelical review', 'theological review',
            'biblical studies', 'conspectus', 'chafer theological',
            'journal of biblical literature', 'journal of theological studies',
            'evangelical quarterly', 'tyndale bulletin',
            'westminster theological journal', 'bibliotheca sacra',
            'trinity journal', 'presbyterian',
            'review and expositor', 'interpretation', 'theology today',
            'biblical archaeologist', 'near eastern archaeology',
            'catholic biblical quarterly', 'currents in biblical research',
            'horizons in biblical theology',
        ],
        'types': ['Journal', 'Periodical'],
        'priority': 850
    },

    # ── II. KLEINE BUCH- & JOURNALREIHEN (Series mit 3-5 Bänden) ─────────
    'II. Kleine Buch- & Journalreihen': {
        'keywords': [
            # Diese Keywords sind jetzt nachrangig - Hauptkriterium ist Series-Count 3-5
        ],
        'types': [],
        'priority': 840
    },

    # ── ANDACHT & SPIRITUALITÄT ──────────────────────────────────────────
    'Andacht & Spiritualität': {
        'keywords': [
            # Andacht & Spiritualität
            'devotional', 'andacht', 'spirituality', 'prayer', 'gebet',
            'spiritual disciplines', 'spiritual formation', 'spiritual growth',
            'desiring god', 'pursuit of god', 'walking with god', 'knowing god',
            'intimacy with god', 'christian life', 'living the christian',
            'morning and evening', 'fellowship with god', 'abiding in christ',
            'christian living', 'disciplines of a godly', 'godliness', 'holiness',
            'the holy spirit', 'spirit-filled', 'daily walk', 'practical christianity',
            'the pursuit', 'drawing near', 'drawing near to god',
            'practicing the presence', 'contemplative', 'silence and solitude',
            'fasting', 'journaling', 'scripture memory',
            'tozer a.w.', 'foster richard', 'willard dallas', 'brother lawrence',
            'thomas a kempis', 'imitation of christ', 'thomas merton',
            'morning devotional', 'evening devotional', '365 devotions', 'daily devotional',
            'daily bread', 'my utmost', 'morning by morning', 'evening by evening',
            'andachtsbuch', 'tageslosung', 'stille zeit', 'geistliches leben',
            'gebetsleben', 'gottsuche', 'christliches leben', 'nachfolge christi',
            # Neu: Adventisten-Bücher (Ellen White etc.)
            'adventist home', 'adventist families', 'adventist men',
            'special testimonies', 'testimonies for the church',
            'white, ellen', 'ellen white', 'ellen g. white',
            'seventh-day adventist', 'adventist church',
            'great controversy', 'desire of ages', 'steps to christ',
            'patriarchs and prophets', 'prophets and kings',
            'acts of the apostles by white', '1919 bible conference',
            'adventist congregations', 'general conference of seventh',
            'logos mobile education',
        ],
        'types': ['Devotional', 'Spirituality', 'ChristianLiving'],
        'priority': 495
    },

    # ── BIBELN ───────────────────────────────────────────────────────────
    'Bibel & Bibelwörterbücher': {
        'keywords': [
            # Deutsche Bibeln
            'lutherbibel', 'schlachter', 'elberfelder', 'zürcher bibel', 'neue genfer',
            'gute nachricht', 'hoffnung für alle', 'einheitsübersetzung',
            'bibelausgabe', 'die bibel', 'heilige schrift', 'neues leben', 'menge bibel',
            # Englische Bibeln
            'holy bible', 'study bible', 'english standard version', 'king james version',
            'new king james', 'new international version', 'new american standard',
            'revised standard version', 'new revised standard', 'new living translation',
            'amplified bible', 'christian standard bible', 'holman christian standard',
            'message bible', 'good news bible', 'net bible', 'recovery bible',
            'reformation heritage kjv', 'geneva bible', 'tyndale bible',
            'interlinear bible', 'greek-english interlinear', 'hebrew-english interlinear',
            'parallel bible', 'bilingual bible',
            # Bibelwörterbücher
            'bible dictionary', 'biblical dictionary', 'dictionary of the bible',
            'bibelwörterbuch', 'bibellexikon', 'biblical encyclopedia',
            'international standard bible', 'isbe ', 'anchor bible dictionary',
            'new bible dictionary', 'illustrated bible dictionary',
            'zondervan bible dictionary', 'unger',
            # Bibelatlanten
            'bible atlas', 'biblical atlas', 'atlas of the bible',
            # Biblia Hebraica / LXX / Griech. NT
            'biblia hebraica', 'septuagint', 'lxx ', 'novum testamentum graece',
            'nestle-aland', 'greek new testament', 'ubs greek',
            # Bibelkunde
            'bibelkunde', 'bibelkompendium', '1000 bilder zur bibel',
            '1001 ways', '4000 questions', 'questions and answers on the bible',
            # Cambridge Bible for Schools
            'cambridge bible for schools',
            # PBB-Bibeln (persönliche Bücher von Hermann Fritz)
        ],
        'types': ['Bible', 'StudyBible', 'BibleDictionary'],
        'priority': 700
    },

    # ── KOMMENTARE ───────────────────────────────────────────────────────
    'Kommentare': {
        'keywords': [
            'commentary', 'kommentar', 'exegetical', 'exegesis of',
            'exposition', 'expository', 'notes on', 'verse by verse', 'verse-by-verse',
            'studies in the book of', 'preaching the word',
            'tyndale commentary', 'word biblical commentary',
            'new international commentary', 'nicnt', 'nigtc', 'nicot',
            'anchor bible', 'hermeneia', 'pillar new testament',
            'new american commentary', 'handbuch zum neuen testament',
            'kritisch-exegetischer kommentar', 'evangelisch-katholischer kommentar',
            'reformed expository commentary', 'mentor commentary',
            'focus on the bible', 'opening up', 'welwyn commentary',
            'john macarthur new testament', 'the macarthur commentary',
            'wiersbe', 'be series', 'be faithful', 'be real', 'be rich',
            'be holy', 'be wise', 'be joyful', 'be right',
            'the bible speaks today', 'bst ',
            'standard bible studies',
            'the practical works of the rev. richard baxter',
            'the works of the rev. isaac watts', 'works of william law',
            'the fathers for english readers',
            'dietrich bonhoeffer works',
            'j. c. ryle collection', 'ryle ',
            'the crucial questions series',
            # ALLE wichtigen Kommentar-Serien:
            'biblical illustrator', 'the biblical illustrator',
            'exposition of the bible', 'pulpit commentary',
            'critical and exegetical commentary', 'cambridge bible',
            'expositors bible commentary', 'new bible commentary',
            'torch bible commentaries', 'daily study bible',
            'believers church bible commentary',
            'abingdon new testament commentaries', 'continental commentaries',
            'interpretation commentary', 'new interpreter commentary',
            'old testament library', 'new testament library',
            'readings commentary', 'proclamation commentaries',
            'geneva series commentaries', 'holman new testament commentary',
        ],
        'types': ['Commentary'],
        'priority': 600
    },

    # ── LEXIKA & WÖRTERBÜCHER ────────────────────────────────────────────
    'Lexika & Wörterbücher': {
        'keywords': [
            'lexicon', 'lexikon', 'dictionary', 'wörterbuch', 'concordance', 'konkordanz',
            'theological dictionary', 'theological wordbook',
            'nidntt', 'nidotte', 'bdag', 'halot', 'twot', 'tdot', 'tdnt',
            'word study', 'word studies', 'greek-english', 'hebrew-english',
            'aramaic dictionary', 'thayer', 'strong', 'young concordance',
            'cruden concordance', 'nave concordance', 'vine expository',
            'expository dictionary', 'complete word study', 'key word study',
            'liddell scott', 'kittel', 'brown driver briggs',
            'gesenius lexicon', 'koehler baumgartner', 'louw-nida',
            'greek lexicon', 'hebrew lexicon', 'analytical lexicon', 'parsing guide',
            # Neu: Lateinische Wörterbücher
            'latin dictionary', 'latin lexicon', 'lewis and short',
            'latin-english', 'english-latin', 'latin grammar',
            'abrégé du dictionnaire', 'dictionnaire grec',
            'greek-hebrew index', 'hebrew-greek index',
            'index to the bible translator',
        ],
        'types': ['Lexicon', 'Dictionary', 'Concordance', 'Wordbook'],
        'priority': 590
    },

    # ── KIRCHENGESCHICHTE ─────────────────────────────────────────────────
    'Kirchengeschichte': {
        'keywords': [
            'church history', 'kirchengeschichte', 'patristic', 'patristics', 'reformation',
            'medieval', 'history of the church', 'history of christianity', 'ante-nicene',
            'nicene fathers', 'early church', 'church fathers', 'apostolic fathers',
            'ancient church', 'protestant history', 'revival history', 'great awakening',
            'augustine', 'thomas aquinas', 'martin luther', 'john calvin biography',
            'john wesley', 'charles spurgeon', 'historical theology',
            'history of doctrine', 'history of dogma', 'reformation history',
            'post-reformation', 'council of trent', 'council of nicaea',
            'philip schaff', 'heresies', 'heresy in the church',
            'revivalism', 'pietism', 'awakenings', 'methodism history',
            'baptists history', 'presbyterianism history', 'puritans history',
            'ante-nicene christianity', 'early christianity', 'origins of christianity',
            'reformationsgeschichte', 'alte kirche',
            # Neu aus sonstige-analyse
            'medford historical society', 'historic leaves',
        ],
        'types': ['ChurchHistory', 'Patristics', 'HistoricalTheology'],
        'priority': 580
    },

    # ── BIBLISCHE SPRACHEN ────────────────────────────────────────────────
    'Biblische Sprachen': {
        'keywords': [
            'hebrew grammar', 'greek grammar', 'aramaic grammar', 'biblical hebrew',
            'biblical greek', 'koine greek', 'new testament greek', 'old testament hebrew',
            'introduction to greek', 'introduction to hebrew',
            'learn greek', 'learn hebrew', 'learning greek', 'learning hebrew',
            'greek vocabulary', 'hebrew vocabulary', 'greek reader', 'hebrew reader',
            'mounce greek', 'wenham greek', 'gesenius hebrew grammar',
            'basics of biblical hebrew', 'basics of biblical greek',
            'beginning biblical hebrew', 'mastering new testament greek',
            'septuagint greek', 'qumran aramaic', 'syriac grammar', 'coptic grammar',
            'ugaritic', 'akkadian', 'ancient semitic', 'semitic linguistics',
            'greek testament', 'greek primer', 'hebrew primer',
            'greek syntax', 'greek accidence', 'brief greek syntax',
            # Neu: Latein (Loeb, Klassiker, Papyrologie)
            'latin text', 'latin grammar', 'latin syntax', 'latin primer',
            'loeb classical library', 'loeb classical',
            'loeb: greek', 'loeb: latin', 'loeb: english',
            # Papyrologie (Duke Papyri etc.)
            'papyri', 'papyrus', 'ostraca', 'documentary papyri',
            'duke data bank', 'corpus papyrorum', 'greek papyri',
            'aramaic papyri', 'illuminierte papyri',
            # Klassische Autoren (Griechisch/Latein)
            'works of aristotle', 'deipnosophists', 'ab urbe condita',
            'harvard classics', 'works of plato',
            # PBB Sprachbücher (Hermann Fritz)
            'greek-hebrew', 'hebrew-greek',
        ],
        'types': ['OriginalLanguage', 'Grammar', 'LanguageLearning'],
        'priority': 570
    },

    # ── SYSTEMATISCHE THEOLOGIE ───────────────────────────────────────────
    'Theologie & Dogmatik': {
        'keywords': [
            'systematic theology', 'dogmatic theology', 'christian doctrine', 'doctrine of',
            'dogmatics', 'confession of faith', 'catechism', 'westminster confession',
            'heidelberg catechism', 'belgic confession', 'three forms of unity',
            'christian theology', 'reformed theology', 'covenant theology',
            'sovereignty of god', 'holiness of god', 'attributes of god',
            'knowing god', 'sola fide', 'sola scriptura', 'five solas',
            'salvation', 'the atonement', 'justification by faith',
            'sanctification', 'election', 'predestination', 'trinity', 'incarnation',
            'institutes of the christian', 'what is the gospel',
            'total depravity', 'penal substitution', 'doctrines of grace',
            'theologie', 'dogmatik', 'glaubenslehre', 'gnadenlehre',
            'trinitätslehre', 'christologie', 'soteriologie', 'ekklesiologie',
            'pneumatologie', 'barth kirchliche dogmatik',
            'summa theologiae', 'summa theologica',
            'berkhof systematic', 'grudem systematic', 'erickson christian theology',
            # Neu aus sonstige-analyse
            'merkmale einer gesunden gemeinde', '9 merkmale',
            'christian standard', 'spectrum multiview books',
        ],
        'types': ['Theology', 'SystematicTheology', 'DoctrinalTheology', 'ConfessionalDocument', 'Catechism'],
        'priority': 560
    },

    # ── HOMILETIK & PREDIGT ───────────────────────────────────────────────
    'Homiletik & Predigt': {
        'keywords': [
            'homiletics', 'homiletik', 'preaching', 'predigt', 'sermon', 'sermons',
            'pulpit', 'art of preaching', 'how to preach',
            'expository preaching', 'expository sermons',
            'supremacy of god in preaching', 'christ-centered preaching',
            'selected sermons', 'complete sermons', 'sermons on', 'sermons from',
            'devotional sermons', 'gospel sermons', 'evangelistic sermons',
            'spurgeon sermons', 'lloyd-jones sermons', 'piper sermons',
            'predigtlehre', 'predigen', 'kanzelberedsamkeit',
            # Neu: Illustrationen & Zitate für Prediger
            '300 illustrations for preachers', '300 quotations for preachers',
            'illustrations for preachers', 'quotations for preachers',
            'pastorum series', 'preacher',
        ],
        'types': ['Homiletics', 'Preaching', 'Sermons'],
        'priority': 550
    },

    # ── HERMENEUTIK & AUSLEGUNG ───────────────────────────────────────────
    'Hermeneutik & Auslegung': {
        'keywords': [
            'hermeneutics', 'hermeneutik', 'biblical interpretation', 'interpretation of',
            'how to read the bible', 'how to study the bible', 'understanding the bible',
            'reading the bible', 'grammatical historical', 'historical-grammatical',
            'introduction to biblical interpretation',
            'guide to bible study', 'methods of bible study',
            'literalism', 'allegorical interpretation', 'typological', 'typology',
            'fee and stuart', 'how to interpret the bible',
            'auslegung', 'schriftauslegung', 'bibelstudium',
            'grundfragen der hermeneutik',
        ],
        'types': ['Hermeneutics', 'BiblicalInterpretation'],
        'priority': 545
    },

    # ── APOLOGETIK & WELTANSCHAUUNG ───────────────────────────────────────
    'Apologetik & Weltanschauung': {
        'keywords': [
            'apologetics', 'apologetik', 'worldview', 'weltanschauung',
            'defense of the faith', 'defending the faith', 'case for christ',
            'case for faith', 'evidence for', 'reasons to believe',
            'faith and reason', 'reason for god', 'can we trust', 'why believe',
            'god exists', 'existence of god', 'problem of evil', 'problem of suffering',
            'presuppositional apologetics', 'classical apologetics',
            'ontological argument', 'cosmological argument', 'teleological argument',
            'mere christianity', 'schaeffer', 'os guinness', 'ravi zacharias',
            'william lane craig', 'alvin plantinga', 'cornelius van til',
            'secular humanism', 'postmodernism', 'relativism', 'atheism',
            'new atheism', 'responding to atheism',
            'glaubensverteidigung', 'weltsicht',
        ],
        'types': ['Apologetics', 'Philosophy', 'ChristianPhilosophy'],
        'priority': 540
    },

    # ── ARCHÄOLOGIE & GESCHICHTE ISRAELS ─────────────────────────────────
    'Archäologie & Geschichte Israels': {
        'keywords': [
            'archaeology', 'archäologie', 'ancient near east', 'near eastern',
            'mesopotamia', 'ancient israel', 'history of israel', 'jewish history',
            'judaism', 'second temple', 'intertestamental', 'dead sea scrolls',
            'qumran', 'nag hammadi', 'egypt and the bible', 'lands of the bible',
            'biblical backgrounds', 'new testament background', 'old testament background',
            'greco-roman background', 'cultural background', 'ancient world',
            'ugarit', 'ebla tablets', 'assyria', 'babylon', 'persia and the bible',
            'excavations at', 'tell ', 'archaeological discoveries',
            'palästinakunde', 'zeitgeschichte jesu', 'umwelt',
            # Neu: Nahöstliche Gesellschaften / Papyrologie als Archäologie
            'near east archaeological', 'pseudepigrapha', 'apocrypha',
            'bibliography of pseudepigrapha', '2 esdras',
        ],
        'types': ['Archaeology', 'AncientHistory', 'JewishStudies'],
        'priority': 535
    },

    # ── BIBLISCHE THEOLOGIE ───────────────────────────────────────────────
    'Biblische Theologie': {
        'keywords': [
            'biblical theology', 'biblical-theological', 'redemptive history',
            'typology', 'promise and fulfillment', 'from eden to',
            'graeme goldsworthy', 'geerhardus vos', 'covenant and kingdom',
            'new testament theology', 'old testament theology', 'theology of',
            'pauline theology', 'johannine theology', 'lukan theology',
            'bultmann theology', 'ladd theology new testament',
            'narrative theology', 'salvation history', 'heilsgeschichte',
            'biblische theologie', 'alttestamentliche theologie',
            'neutestamentliche theologie',
        ],
        'types': ['BiblicalTheology'],
        'priority': 530
    },

    # ── ALTES TESTAMENT ──────────────────────────────────────────────────
    'Altes Testament': {
        'keywords': [
            'old testament', 'altes testament', 'pentateuch', 'torah', 'hebrew bible',
            'tanak', 'tanakh', 'hebrew scriptures',
            'genesis', 'exodus', 'leviticus', 'numbers', 'deuteronomy',
            'joshua', 'judges', 'ruth', '1 samuel', '2 samuel', '1 kings', '2 kings',
            '1 chronicles', '2 chronicles', 'ezra', 'nehemiah', 'esther',
            'job ', 'psalm', 'psalms', 'proverbs', 'ecclesiastes',
            'song of solomon', 'song of songs',
            'isaiah', 'jeremiah', 'lamentations', 'ezekiel', 'daniel',
            'hosea', 'joel ', 'amos ', 'obadiah', 'jonah', 'micah', 'nahum',
            'habakkuk', 'zephaniah', 'haggai', 'zechariah', 'malachi',
            '1. mose', '2. mose', '3. mose', '4. mose', '5. mose',
            'josua', 'richter', 'rut ', 'hiob', 'sprüche', 'prediger',
            'hoheslied', 'jesaja', 'jeremia', 'hesekiel',
        ],
        'priority': 520
    },

    # ── NEUES TESTAMENT ───────────────────────────────────────────────────
    'Neues Testament': {
        'keywords': [
            'new testament', 'neues testament', 'synoptic', 'synoptic gospels',
            'the gospels', 'gospel of',
            'matthew', 'mark ', 'luke ', 'john ', 'acts of the apostles', 'book of acts',
            'romans', '1 corinthians', '2 corinthians', 'galatians', 'ephesians',
            'philippians', 'colossians', '1 thessalonians', '2 thessalonians',
            '1 timothy', '2 timothy', 'titus ', 'philemon', 'hebrews', 'james ',
            '1 peter', '2 peter', '1 john', '2 john', '3 john', 'jude ', 'revelation',
            'matthäus', 'markus', 'lukas', 'johannes', 'apostelgeschichte',
            'römer', 'römerbrief', 'galater', 'epheser', 'philipper', 'kolosser',
            'thessalonicher', 'timotheus', 'titusbrief', 'hebräer',
            'jakobusbrief', 'petrusbrief', 'johannesbriefe', 'offenbarung',
            # Neu: PBB-Bibelstudien (Paul Apple, Andreas Janssen etc.)
            'outline of john', 'outline of mark', 'outline of',
        ],
        'priority': 519
    },

    # ── MISSION & EVANGELISATION ──────────────────────────────────────────
    'Mission & Evangelisation': {
        'keywords': [
            'mission', 'missions', 'evangelism', 'evangelisation', 'missionary',
            'cross-cultural', 'world mission', 'unreached peoples', 'church planting',
            'global mission', 'making disciples', 'let the nations', 'to the ends of the earth',
            'missiology', 'missional', 'contextualization', 'indigenous church',
            'donald mcgavran', 'ralph winter', 'david bosch',
            'evangelization', 'evangelistic', 'witnessing', 'personal evangelism',
            'evangelisation', 'gemeindemission', 'volksmission',
            'introduce others to jesus', 'introduce your child to the bible',
        ],
        'types': ['Missions', 'Evangelism', 'Missiology'],
        'priority': 510
    },

    # ── PRAKTISCHE THEOLOGIE ──────────────────────────────────────────────
    'Praktische Theologie': {
        'keywords': [
            'practical theology', 'pastoral theology', 'pastoral ministry',
            'church leadership', 'church growth', 'worship', 'liturgy',
            'church membership', 'church discipline', 'eldership', 'deacon',
            'ministry of', 'the pastor', 'the minister', 'pastor as',
            'small group', 'discipleship', 'discipling', 'christian education',
            'sunday school', 'youth ministry', 'children ministry',
            'marriage and family', 'parenting', 'christian family',
            'the local church', '9marks', 'what is a healthy church',
            'leadership', 'congregational', 'polity', 'church revitalization',
            'praktische theologie', 'seelsorgelehre', 'gemeindeaufbau',
            'gottesdienst', 'liturgik', 'ältestendienst',
            # Neu aus sonstige-analyse
            'you can!', 'things any congregation can do',
            'things anyone can do', 'help their church',
            'logos mobile education',
            '7 power principles', 'power principles',
            'seminary', 'after seminary',
        ],
        'types': ['PracticalTheology', 'Ministry', 'ChurchMinistry'],
        'priority': 505
    },

    # ── SEELSORGE ─────────────────────────────────────────────────────────
    'Seelsorge': {
        'keywords': [
            'counseling', 'seelsorge', 'pastoral care', 'pastoral counseling',
            'biblical counseling', 'christian counseling', 'nouthetic counseling',
            'therapy', 'psychology', 'depression', 'anxiety', 'trauma',
            'grief', 'suffering', 'addiction', 'recovery', 'mental health',
            'inner healing', 'emotional healing', 'when god weeps',
            'problem of pain', 'in the midst of', 'walking through grief',
            'a grief observed', 'good grief', 'a grace disguised',
            'crisis counseling', 'premarital counseling', 'marriage counseling',
            'seelsorge', 'trauerbewältigung',
            # Neu aus sonstige-analyse
            '12 steps with jesus', 'saving graces', 'living above the deadly sins',
            'doubt-free wedding', 'date night ideas', 'married couples',
            'sex ', 'sexuality', 'hot mama', 'relationship secrets',
            '9 must-have conversations',
        ],
        'types': ['Counseling', 'PastoralCare', 'BiblicalCounseling'],
        'priority': 500
    },

    # ── ESCHATOLOGIE ──────────────────────────────────────────────────────
    'Eschatologie': {
        'keywords': [
            'eschatology', 'eschatologie', 'end times', 'last things', 'last days',
            'apocalypse', 'apocalyptic', 'prophecy', 'prophetic', 'rapture',
            'millennium', 'millennial', 'second coming', 'return of christ',
            'kingdom of god', 'kingdom of heaven', 'new heaven', 'new earth',
            'eternity', 'heaven', 'hell', 'hades', 'judgment', 'great tribulation',
            'book of revelation', 'revelation commentary', 'four views on',
            'amillennial', 'premillennial', 'postmillennial', 'dispensationalism',
            'already and not yet', 'inaugurated eschatology',
            'endzeitlehre', 'wiederkunft christi', 'auferstehung', 'jüngstes gericht',
            'ewiges leben', 'tausendjähriges reich',
        ],
        'types': ['Eschatology', 'Prophecy', 'Apocalyptic'],
        'priority': 490
    },

    # ── ETHIK ─────────────────────────────────────────────────────────────
    'Ethik': {
        'keywords': [
            'ethics', 'ethik', 'moral', 'morality', 'christian ethics', 'bioethics',
            'sexual ethics', 'ethical', 'social justice', 'social ethics',
            'abortion', 'euthanasia', 'capital punishment', 'just war',
            'political theology', 'public theology', 'natural law',
            'human dignity', 'rights and responsibilities',
            'marriage and sexuality', 'gender ethics', 'transgender',
            'christliche ethik', 'sozialethik', 'bioethik', 'moraltheologie',
        ],
        'types': ['Ethics', 'ChristianEthics', 'SocialEthics'],
        'priority': 485
    },

    # ── BIOGRAFIEN ────────────────────────────────────────────────────────
    'Biografien': {
        'keywords': [
            'biography', 'biographie', 'life of', 'leben von', 'memoir', 'autobiography',
            'letters of', 'journals of', 'diary of', 'correspondence of',
            'the life and', 'life and times', 'reminiscences',
            'selected letters', 'collected letters', 'memoir of',
            'hudson taylor', 'david livingstone', 'amy carmichael',
            'corrie ten boom', 'jim elliot',
            'lebensbild', 'lebensbeschreibung', 'biografie',
            # Neu aus sonstige-analyse
            '365 days with newton', '365 days with spurgeon', '365 days with',
            'days with newton', 'days with spurgeon',
            '10 people every christian should know',
            '131 christians everyone should know',
        ],
        'types': ['Biography', 'Memoir', 'Autobiography'],
        'priority': 480
    },

    # ── NACHSCHLAGEWERKE ──────────────────────────────────────────────────
    'Nachschlagewerke': {
        'keywords': [
            'encyclopedia', 'enzyklopädie', 'handbook', 'handbuch', 'companion',
            'introduction to', 'a survey of', 'overview of', 'guide to', 'guide for',
            'atlas', 'concise dictionary', 'concise encyclopedia',
            'complete handbook', 'reference guide', 'quick reference',
            'illustrated guide', 'visual guide', 'visual survey',
            'eerdmans handbook', 'zondervan handbook',
            'survey of the old testament', 'survey of the new testament',
            'survey of church history', 'overview of christian theology',
            'einführung in', 'grundriss', 'handbuch der', 'leitfaden',
            'überblick über', 'einleitung in', 'kompendium',
            # Neu aus sonstige-analyse
            '101 questions', '101 quick questions', '102 fascinating bible studies',
            'questions and answers', 'questions every christian',
            '10 questions every christian', '52 bible verses', '52 weeks through',
            'faithlife biblische und theologische listen', 'faithlife biblical',
            '100 years of cinema', 'pontifical council',
            'moreau dictionary', 'dictionary of missions',
        ],
        'types': ['Reference', 'Encyclopedia', 'Handbook', 'Introduction'],
        'priority': 470
    },

    # ── BIBELSTUDIUM ───────────────────────────────────────────────────────
    'Bibelstudium': {
        'keywords': [
            'bible study', 'bibelstudium', 'bible study guide', 'bible study helps',
            'inductive bible study', 'how to study the bible', 'studying the bible',
            'bible study methods', 'bible reading plan', 'bible study notes',
            'daily bible', 'devotional guide', 'scripture study',
            'transforming word', 'scripture engagement',
            'overview of the bible', 'the bible overview', 'bible overview',
            'bible survey', 'survey of the bible', 'introductory guide to the bible',
            'understanding the bible', 'exploring the bible',
            'reading the bible', 'reading guide to the bible',
            'journey through the bible', 'walk through the bible',
            'bible in 90 days', 'one year bible', 'chronological bible',
            'the whole bible story', 'the bible story',
            'good book', 'guide to the bible', 'the bible guide',
            'bible reading made easy', 'bible study made easy',
            'an approach to extended memorization of scripture',
            'footsteps through the bible', 'promises kept: the whole story',
            'all roads lead to the text',
        ],
        'types': ['BibleStudy', 'Study'],
        'priority': 462
    },

    # ── KARTEN & LANDKARTEN ────────────────────────────────────────────────
    'Landkarten & Atlanten': {
        'keywords': [
            # Atlanten
            'atlas of the bible', 'bible atlas', 'biblical atlas', 'zondervan atlas',
            'macmillan bible atlas', 'westminster historical atlas', 'westminster bible atlas',
            'oxford bible atlas', 'student bible atlas', 'new moody atlas', 'moody atlas',
            'baker illustrated bible atlas', 'holman bible atlas', 'carta bible atlas',
            'carta\'s new century hand-atlas', 'new bible atlas',
            # Karten-Sammlungen (Logos)
            'logos deluxe map set', 'logos maps', 'logos bible map', 'logos 6 maps',
            'logos 7 maps', 'logos 8 maps',
            # Nelson Karten
            "nelson's bible map", "nelson's 3-d bible mapbook", "nelson's complete book of bible maps",
            "nelson's complete book of bible maps and charts",
            # Geographie
            'geography of the holy land', 'historical geography of the holy land',
            'physical geography of the holy land', 'geography of palestine',
            'geography of bible lands', 'geographical companion to the bible', 'bible geography',
            'sacred geography', 'holy land geography',
            # Topographie
            'topography of jerusalem', 'underground jerusalem', 'jerusalem and its vicinity',
            'survey of israel', 'survey of the land', 'new testament places',
            'eerdmans dictionary of the bible geography',
            # Beitzel
            'beitzel photo library', 'barry beitzel',
            # Reisen & Pilgerreisen
            'journeys of the apostle paul', 'journeys of jesus', "paul's missionary journeys",
            'missionary journeys', 'traveling in the holy land', 'travel through israel',
            'through the land of the bible',
            # Bilder vom Heiligen Land
            'images of the holy land', 'exploring the holy land',
            'images from the illustrated bible treasury', 'images from a standard bible dictionary',
            'images from the temple dictionary', 'images from a dictionary of the bible',
            'images from illustrations of the bible', 'images from the bible hand-book',
            'images from helps to the study of the bible',
            'stereoscopic images of the middle east',
            'an illustrated history of the holy bible',
            # Biblische Geographie Lehrwerke
            'a study guide of israel', 'study guide of israel',
            'window into the bible: cultural and historical', 'windows into the bible',
            'seeing israel from the sky', 'geography through the eyes of faith',
        ],
        'types': ['Map', 'Atlas', 'Geography'],
        'priority': 460
    },

    # ── PERSÖNLICHE BÜCHER ─────────────────────────────────────────────────
    # (Logos Personal Books mit pbb: Ressource-ID, vom Nutzer erstellt)
    'Persönliche Bücher': {
        'keywords': [],  # Wird direkt über pbb: ID-Erkennung befüllt
        'priority': 450
    },

    # ── SONSTIGE (Fallback) ───────────────────────────────────────────────
    'Sonstige': {'is_default': True}
}

# ============================================================

# ============================================================
# LOGOS-INSTALLATION SUCHEN
# ============================================================
def find_catalogs():
    system = platform.system()
    paths = []
    bases = ['Logos', 'Logos10', 'Logos9', 'Logos8', 'Verbum', 'Verbum9', 'Verbum10']
    if system == "Windows":
        appdata = os.environ.get('LOCALAPPDATA', '')
        appdata_roaming = os.environ.get('APPDATA', '')
        for search_root in [appdata, appdata_roaming]:
            if not search_root:
                continue
            for base in bases:
                # Standard pattern: Logos/Data/[ID]/LibraryCatalog
                paths.extend(glob.glob(os.path.join(search_root, base, 'Data', '*', 'LibraryCatalog')))
                # Fallback: *.wdb pattern (newer Logos versions, e.g. C. Wootten: zanjcngh.wdb)
                paths.extend(glob.glob(os.path.join(search_root, base, 'Data', '*.wdb', 'LibraryCatalog')))
                # Direct catalog.db without LibraryCatalog subfolder
                paths.extend(glob.glob(os.path.join(search_root, base, 'Data', '*')))
    elif system == "Darwin":
        home = str(Path.home())
        for base in bases:
            paths.extend(glob.glob(os.path.join(home, 'Library', 'Application Support', base, 'Data', '*', 'LibraryCatalog')))
            paths.extend(glob.glob(os.path.join(home, 'Library', 'Application Support', base, 'Data', '*.wdb', 'LibraryCatalog')))
            paths.extend(glob.glob(os.path.join(home, 'Library', 'Application Support', base, 'Data', '*')))
    else:  # Linux
        home = str(Path.home())
        for base in bases:
            # Native Linux (wenn Logos nativ laufen würde)
            paths.extend(glob.glob(os.path.join(home, '.local', 'share', base, 'Data', '*', 'LibraryCatalog')))
            paths.extend(glob.glob(os.path.join(home, '.local', 'share', base, 'Data', '*.wdb', 'LibraryCatalog')))
            paths.extend(glob.glob(os.path.join(home, '.local', 'share', base, 'Data', '*')))
            # Wine standard prefix
            paths.extend(glob.glob(os.path.join(home, '.wine', 'drive_c', 'users', '*', 'AppData', 'Local', base, 'Data', '*', 'LibraryCatalog')))
            paths.extend(glob.glob(os.path.join(home, '.wine', 'drive_c', 'users', '*', 'AppData', 'Local', base, 'Data', '*.wdb', 'LibraryCatalog')))
            # Wine custom prefix (WINEPREFIX)
            paths.extend(glob.glob(os.path.join(home, '.wine*', 'drive_c', 'users', '*', 'AppData', 'Local', base, 'Data', '*', 'LibraryCatalog')))
            # Bottles (Flatpak)
            paths.extend(glob.glob(os.path.join(home, '.var', 'app', 'com.usebottles.bottles', 'data', 'bottles', 'bottles', '*', 'drive_c', 'users', '*', 'AppData', 'Local', base, 'Data', '*', 'LibraryCatalog')))
            paths.extend(glob.glob(os.path.join(home, '.var', 'app', 'com.usebottles.bottles', 'data', 'bottles', 'bottles', '*', 'drive_c', 'users', '*', 'AppData', 'Local', base, 'Data', '*.wdb', 'LibraryCatalog')))
            # Bottles (non-Flatpak)
            paths.extend(glob.glob(os.path.join(home, '.local', 'share', 'bottles', 'bottles', '*', 'drive_c', 'users', '*', 'AppData', 'Local', base, 'Data', '*', 'LibraryCatalog')))
    # Deduplizieren und nur Pfade mit catalog.db behalten
    seen = set()
    valid = []
    for p in paths:
        p_norm = os.path.normpath(p)
        if p_norm in seen:
            continue
        seen.add(p_norm)
        if os.path.exists(os.path.join(p, 'catalog.db')):
            valid.append(p)
    if not valid:
        valid = prompt_manual_selection(system)
    return valid

def prompt_manual_selection(system):
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox
        root = tk.Tk()
        root.withdraw()
        if system == "Windows":
            hint = "C:\\Users\\[Name]\\AppData\\Local\\Logos\\Data\\[ID]\\LibraryCatalog"
        elif system == "Darwin":
            hint = "~/Library/Application Support/Logos/Data/[ID]/LibraryCatalog"
        else:
            hint = "~/.wine/drive_c/users/[Name]/AppData/Local/Logos/Data/[ID]/LibraryCatalog\noder: ~/.var/app/com.usebottles.bottles/data/bottles/bottles/[BottleName]/drive_c/users/[Name]/AppData/Local/Logos/Data/[ID]/LibraryCatalog"
        messagebox.showinfo(
            "Logos/Verbum nicht gefunden",
            f"Keine Logos/Verbum-Installation automatisch gefunden!\n\nBitte wählen Sie den 'LibraryCatalog' Ordner:\n{hint}\n\n(Der Ordner muss 'catalog.db' enthalten)"
        )
        folder = filedialog.askdirectory(title="Logos/Verbum LibraryCatalog Ordner wählen")
        root.destroy()
        if folder and os.path.exists(os.path.join(folder, 'catalog.db')):
            return [folder]
    except:
        print("\n⚠️  Keine Logos/Verbum-Installation gefunden!")
        print("Bitte Pfad zum LibraryCatalog Ordner eingeben:")
        manual = input("Pfad: ").strip().strip('"')
        if os.path.exists(os.path.join(manual, 'catalog.db')):
            return [manual]
    return []

# ============================================================
# BUCHKATEGORISIERUNG
# ============================================================
def categorize_book(title, resource_id, subject_groups, authors='', series='', series_analysis=None):
    title_l   = (title or '').lower()
    rid_l     = (resource_id or '').lower()
    subj_l    = (subject_groups or '').lower()
    auth_l    = (authors or '').lower()
    series_l  = (series or '').lower()
    full_text = f"{title_l} {rid_l} {subj_l} {auth_l} {series_l}"
    
    # ═══════════════════════════════════════════════════════════
    # HÖCHSTE PRIORITÄT: SERIES-BASIERTE KATEGORISIERUNG
    # ═══════════════════════════════════════════════════════════
    if series_analysis and series and series.strip():
        series_clean = series.strip().lower()
        
        # I. Journale & Magazine: Series mit >5 Bänden
        if series_clean in series_analysis['journale_i']:
            return 'I. Journale & Magazine'
        
        # II. Kleine Buch- & Journalreihen: Series mit 3-5 Bänden
        if series_clean in series_analysis['kleine_reihen']:
            return 'II. Kleine Buch- & Journalreihen'
    
    # ═══════════════════════════════════════════════════════════
    # LANDKARTEN & ATLANTEN: Globale Konsolidierung
    # ═══════════════════════════════════════════════════════════
    geography_keywords = [
        'atlas', 'map', 'maps', 'geography', 'geographical',
        'geographie', 'landkarte', 'weltatlas', 'bibel-atlas',
        'bible atlas', 'biblical atlas', 'historical atlas',
        'cartography', 'topography', 'gazetteer',
        'historical geography', 'geography of palestine',
        'geography of the', 'geographie der', 'geographisch',
        'kartographie', 'karte von', 'atlas of', 'atlas der'
    ]
    
    if any(kw in full_text for kw in geography_keywords):
        # Ausnahmen: Nicht jedes "atlas/map" ist Geographie
        exceptions = [
            'atlas of world', 'linguistic atlas', 'dialect atlas',
            'road map', 'roadmap', 'practical', 'marriage', 'guide',
            'journey', 'getting ready', 'novella', 'novel', 'fiction'
        ]
        if not any(ex in full_text for ex in exceptions):
            return 'Landkarten & Atlanten'

    # Early American History – spezielle Erkennung
    # LLS:EVANS* sind historische amerikanische Dokumente (Evans Digital Collection, ~1640-1820)
    if rid_l.startswith('lls:evans'):
        return 'Early American History'
    eah_patterns = [
        'library of early american', 'early american history', 'puritan',
        'colonial america', 'new england history', 'founding fathers',
        'american revolution', 'cotton mather', 'increase mather',
        'jonathan edwards', 'john winthrop', 'george whitefield biography',
        'new-england', 'province of', 'colony of', 'delivered before the',
        'delivered to the', 'oration delivered', 'sermon delivered at',
        'general court', 'colonial', 'boston printed', 'confederate',
        'civil war history', 'southern historical society', 'confederate military',
        'photographic history of the civil war', 'founders journal',
    ]
    if any(p in full_text for p in eah_patterns):
        return 'Early American History'
    if 'earlyamerican' in full_text.replace('-', '').replace('_', '').replace(' ', ''):
        return 'Early American History'

    # Personal Books: Logos-Bücher die der Nutzer selbst hochgeladen/erstellt hat
    # ResourceId-Präfix: 'pb:' (neuere Logos-Versionen) oder 'pbb:' (ältere Versionen)
    if rid_l.startswith('pb:') or rid_l.startswith('pbb:'):
        return 'Persönliche Bücher'

    # Duke Papyri + alle Papyrologie → Biblische Sprachen
    if 'lls:ddbdp' in rid_l or 'duke data bank' in series_l or 'duke data bank' in full_text:
        return 'Biblische Sprachen'

    # DB: Datasets → Nachschlagewerke
    if rid_l.startswith('db:'):
        return 'Nachschlagewerke'

    # INTERACTIVE: Interaktive Logos-Ressourcen → Nachschlagewerke
    if rid_l.startswith('interactive:'):
        return 'Nachschlagewerke'

    # RVI: Reverse Interlinear → Bibel & Bibelwörterbücher
    if rid_l.startswith('rvi:'):
        return 'Bibel & Bibelwörterbücher'

    # GreekLem: Griechische Lexeme → Biblische Sprachen
    if rid_l.startswith('greeklem'):
        return 'Biblische Sprachen'

    # SERIEN-BASIERTE Erkennung für spezifische, nicht-bandanzahl-basierte Zuordnungen
    # (Journale & Magazine I und Kleine Reihen II werden jetzt dynamisch durch Series-Analyse zugeordnet)
    SERIES_CATEGORIES = {
        'Kommentare': [
            'the crucial questions series', 'the practical works of the rev. richard baxter',
            # KRITISCH: Biblical Illustrator hinzufügen
            'biblical illustrator', 'the biblical illustrator',
            'the cambridge bible for schools and colleges', 'dietrich bonhoeffer works',
            'the bible speaks today', 'the fathers for english readers',
            'standard bible studies', 'knowing the bible',
            'david guzik commentaries on the bible', 'j. c. ryle collection',
            '365 days with spurgeon', '365 days with newton',
            'pastorum series',
        ],
        'Biblische Sprachen': [
            'ab urbe condita (weissenborn) latin text',
            'ab urbe condita (weissenborn) textual notes',
            'ab urbe condita (foster-moore-sage) english text',
            'ab urbe condita (foster-moore-sage) latin text',
            'the works of aristotle', 'the deipnosophists',
            'works of plato', 'loeb classical library',
            'maimonides treatise on logic',
        ],
        'Nachschlagewerke': [
            'faithlife biblische und theologische listen',
            'faithlife biblical and theological lists',
            'logos mobile education', 'syndicate', 'you can!',
        ],
        'Andacht & Spiritualität': [
            'celebration of faith', 'studies in faithful living',
            'obras completas de santa teresa de jesús',
            'the daughters of caleb bender', 'southern crimes',
            'christian community in history',
        ],
        'Seelsorge': [
            'hot mama challenge', '101 quick questions with catholic answers',
            '101 questions and answers series',
        ],
        'Praktische Theologie': [
            'you can!',
        ],
        'Archäologie & Geschichte Israels': [
            'the bulletin series of the near east archaeological society: new series',
            'the bulletin series of the near east archaeological society',
        ],
        'Kirchengeschichte': [
            'medford historical society papers', 'historic leaves',
        ],
    }
    
    for cat, series_list in SERIES_CATEGORIES.items():
        if series_l and any(s in series_l for s in series_list):
            return cat

    # TITEL-KEYWORD-ERKENNUNG für bekannte Muster
    # Griechische/Lateinische Klassiker (Plutarch, Caesar, Aristoteles etc.)
    greek_latin_patterns = [
        'bacchae', 'bacchides', 'fabius maximus', 'galba ', 'gallic war',
        'gallieni', 'halieutica', 'hamartigenia', 'caius gracchus', 'caius marcius',
        'lacaenarum', 'macrobii', 'quaestiones convivales', 'quaestiones graecae',
        'quaestiones romanae', ' (greek)', ' (latin)', 'fabulae aesopiae',
        'ab urbe condita', 'aeneid', 'deipnosophists',
        # Plutarch-Titel
        'themistocles', 'solon ', 'lycurgus', 'pericles', 'alcibiades',
        'coriolanus', 'demosthenes', 'cicero life', 'caesar life', 'brutus life',
        'antonius', 'numa ', 'romulus life',
        # Weitere Klassiker
        'seneca letters', 'seneca moral', 'horace odes', 'horace satires',
        'virgil aeneid', 'ovid metamorphoses', 'livy history', 'tacitus annals',
        'suetonius lives', 'juvenal satires', 'thucydides history',
        'herodotus histories', 'xenophon', 'isocrates', 'pindar odes',
        'homer iliad', 'homer odyssey', 'hesiod', 'sophocles', 'euripides plays',
        'aeschylus', 'aristophanes', 'plautus', 'terence comedies',
    ]
    if any(p in title_l for p in greek_latin_patterns):
        return 'Biblische Sprachen'
    
    # Wenn Titel (English) oder (Greek) oder (Latin) enthält → Klassiker
    if title_l.endswith(' (greek)') or title_l.endswith(' (latin)') or title_l.endswith(' (english)'):
        # Nur wenn es sich um antike Texte handelt (nicht "Adventist Today (English)")
        if not any(x in title_l for x in ['adventist', 'today', 'journal', 'magazine']):
            return 'Biblische Sprachen'

    # Bibeln in anderen Sprachen
    other_bible_patterns = [
        'la bible louis segond', 'la sacra bibbia', 'raamattu', 'bibbia sacra',
        'segond 1910', 'louis segond', 'la santa biblia',
        'die bibel auf', 'bibel auf', 'chinese union',
    ]
    if any(p in title_l for p in other_bible_patterns):
        return 'Bibel & Bibelwörterbücher'

    # Interlinear / Handschriften / Textual Tools
    manuscript_patterns = [
        'handschriften der hebräischen', 'handschriften des griechischen',
        'reverse interlinear', 'greek nt alignment', 'greek new testament alignment',
        'apocrypha english-greek', 'apocrypha variants',
        'la sacra bibbia: notes',
    ]
    if any(p in title_l for p in manuscript_patterns):
        return 'Biblische Sprachen'

    # Ehe, Familie & Erziehung
    family_patterns = [
        'married couples', 'date night', 'hot mama', 'relationship secrets',
        'raising ', 'parenting ', 'raising dad', 'raising kids', 'raising disciples',
        'raising modern', 'marriage ', 'for your spouse', 'husband ', 'wife ',
        'family devotion', 'childrens ministry', 'christian parenting',
        'mad about us', 'must-have conversations', 'doubt-free wedding',
        'red hot sex', 'fashion fixes', 'feel confident', 'body and soul',
    ]
    if any(p in title_l for p in family_patterns):
        return 'Seelsorge'

    # Christliches Leben / Andacht (nicht oben erfasst)
    cl_patterns = [
        '10 minutes a day with jesus', '10 things jesus never said',
        'made for more', 'named by god', 'i am a church member',
        'dare you not to bore me', 'want to believe',
        'a god-centered church', 'keep a quiet heart', 'keep your greek',
        'daily guidance', 'oasis: a spa', 'ears from harvested',
        'earthly footsteps', '40 days to the cross', '52 bible verses',
        '52 weeks through the bible', '7 simple choices',
        'born again and growing', 'faith facts bible',
    ]
    if any(p in title_l for p in cl_patterns):
        return 'Andacht & Spiritualität'

    # Nachschlagewerke / Zahlen-basierte Bücher
    ref_patterns = [
        '100 years of cinema', '101 questions', '101 quick questions',
        '102 fascinating bible studies', '131 christians everyone',
        '1000 bilder zur bibel', '1001 ways to introduce',
        '10 people every christian', '4000 questions',
        'factbook media database', 'parables of the bible: dataset',
        'daf yomi', 'dake topics', 'kairos: answer',
        'keys to the bible', 'keys to the',
        'nailing down a board', 'pontifical council',
    ]
    if any(p in title_l for p in ref_patterns):
        return 'Nachschlagewerke'

    # Apologetik  
    apol_patterns = [
        'hard questions about christianity', 'papism in the',
        'i want to believe: finding', '10 questions every christian must',
        'a christian theory of knowledge', 'a discourse of the grounds',
        'discourse upon the origin', 'a discourse on the formation',
    ]
    if any(p in title_l for p in apol_patterns):
        return 'Apologetik & Weltanschauung'

    # Kirchengeschichte
    ch_patterns = [
        'a concise history of the christian church', 'early christian creeds',
        'early jewish and christian', 'a course of lectures on the jews',
        'a continuation of the chronicles of ireland',
        'narrative of military operations during the civil war',
        'a daily calendar of saints', 'a blockaded family',
        'a book of american explorers',
    ]
    if any(p in title_l for p in ch_patterns):
        return 'Kirchengeschichte'

    # Patristik
    patristic_patterns = [
        'a plea regarding christians by athenagoras',
        'a priest to the temple', 'a body of divinity',
        'the cloud of unknowing', 'a day in the temple',
    ]
    if any(p in title_l for p in patristic_patterns):
        return 'Kirchengeschichte'

    # Punkte für alle anderen Kategorien berechnen
    scores = {}
    for cat, rules in CATEGORIES.items():
        if rules.get('is_default') or cat == 'Early American History':
            continue
        score = 0
        # Keywords prüfen (höheres Gewicht für Titel)
        for kw in rules.get('keywords', []):
            if kw in title_l:
                score += 50
            elif kw in rid_l:
                score += 30
            elif kw in subj_l:
                score += 20
            elif kw in auth_l:
                score += 10
            elif kw in series_l:
                score += 15
        # SubjectGroup-Typen prüfen (sehr zuverlässig)
        for t in rules.get('types', []):
            if t.lower() in subj_l:
                score += 100
        if score > 0:
            scores[cat] = score + rules.get('priority', 0)

    if scores:
        best = max(scores.items(), key=lambda x: x[1])
        if best[1] > 0:
            return best[0]
    return None

# ============================================================
# BÜCHER LADEN
# ============================================================
# ============================================================
# SERIES-ANALYSE (für präzise Kategorisierung)
# ============================================================
def analyze_series(books_data):
    """
    Analysiert alle Series und zählt Bandanzahl.
    Filtert echte Journale mit Keywords.
    Returns: dict mit Series → count, und Sets für Kategorisierung
    """
    from collections import Counter
    
    series_counter = Counter()
    series_to_books = {}
    
    # Journal-Keywords
    journal_kw = [
        'journal', 'review', 'bulletin', 'quarterly', 'annual', 'magazine',
        'zeitschrift', 'revue', 'revista', 'studia', 'acta', 'annals',
        'proceedings', 'transactions', 'periodical'
    ]
    
    # Große Buchreihen ausschließen
    exclude_kw = [
        'works of', 'collected works', 'complete works', 'gesammelte werke',
        'commentary', 'kommentar', 'bible speaks today', 'loeb classical',
        'fathers for english readers', 'word biblical', 'nicot', 'nicnt'
    ]
    
    for rec_id, res_id, title, authors, subj, series in books_data:
        if series and series.strip():
            series_clean = series.strip()
            series_counter[series_clean] += 1
            if series_clean not in series_to_books:
                series_to_books[series_clean] = []
            series_to_books[series_clean].append((title, res_id))
    
    # Kategorisiere
    journale_i_series = set()      # NUR Journale >5 Ausgaben
    kleine_reihen_series = set()   # NUR Journale 2-5 ODER erkennbare Buchreihen 2-5
    
    # Patterns die auf echte BUCHREIHEN hinweisen
    buchreihen_patterns = [
        'series', 'collection', 'library', 'set', 'reihe', 'sammlung',
        'volume', 'vol.', 'band', 'teil', 'part', 'number', 'no.',
        'knowing the bible', 'crucial questions', 'studies in'
    ]
    
    for series_name, count in series_counter.items():
        series_lower = series_name.lower()
        
        # I. Journale & Magazine: >5 UND Journal-Keywords
        if count > 5:
            if any(ex in series_lower for ex in exclude_kw):
                continue
            if any(kw in series_lower for kw in journal_kw):
                journale_i_series.add(series_lower)
        
        # II. Kleine Reihen: 2-5 Bände
        elif 2 <= count <= 5:
            # NUR wenn es ein Journal IST oder erkennbar eine Buchreihe
            is_journal = any(kw in series_lower for kw in journal_kw)
            is_buchreihe = any(pat in series_lower for pat in buchreihen_patterns)
            
            if is_journal or is_buchreihe:
                kleine_reihen_series.add(series_lower)
    
    print(f"\n📊 Series-Analyse:")
    print(f"   Total Series: {len(series_counter)}")
    print(f"   Journale I (>5 Ausgaben + Keywords): {len(journale_i_series)}")
    print(f"   Kleine Reihen II (2-5 Bände): {len(kleine_reihen_series)}")
    
    # Top 20 Journale
    j_list = [(n, c) for n, c in series_counter.items() if n.lower() in journale_i_series]
    j_list.sort(key=lambda x: x[1], reverse=True)
    print(f"\n   Top 20 Journale:")
    for name, cnt in j_list[:20]:
        print(f"      {cnt:3d}x {name[:60]}")
    
    return {
        'counter': series_counter,
        'journale_i': journale_i_series,
        'kleine_reihen': kleine_reihen_series,
        'series_to_books': series_to_books
    }

def load_books(db_path):
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    cur = conn.cursor()

    # Prüfe verfügbare Spalten in Records (Logos-Version-unabhängig)
    cur.execute("PRAGMA table_info(Records)")
    rec_cols = {row[1] for row in cur.fetchall()}
    print(f"📋 Records-Spalten gefunden: {len(rec_cols)} Spalten")

    # Nur eigene Bücher laden: Kombination aus Accessible=1 UND/ODER DownloadStatus
    # Logos speichert nicht-eigene Bücher (Shop/Wishlist) mit Accessible=0
    # Hinweis: Accessible=1 allein kann auch kostenlose/Sample-Ressourcen enthalten.
    # Die strengste Filterung: Accessible=1 AND DownloadStatus IS NOT NULL
    if 'Accessible' in rec_cols and 'DownloadStatus' in rec_cols:
        owned_filter = "AND r.Accessible = 1 AND r.DownloadStatus IS NOT NULL"
        print("✅ Filter: Accessible=1 AND DownloadStatus IS NOT NULL (strengste Filterung)")
    elif 'Accessible' in rec_cols:
        owned_filter = "AND r.Accessible = 1"
        print("✅ Filter: Accessible = 1 (nur eigene Bücher)")
    elif 'DownloadStatus' in rec_cols:
        owned_filter = "AND r.DownloadStatus IS NOT NULL"
        print("✅ Filter: DownloadStatus IS NOT NULL")
    else:
        owned_filter = ""
        print("⚠️  Kein Eigentums-Filter verfügbar - alle Records werden geladen")

    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ResourceSubjectGroups'")
    has_sg = cur.fetchone() is not None

    # ── TAG-ERKENNUNG: Logos-Nutzertags "pb" aus DB lesen ─────────────────
    # Logos speichert Nutzertags in verschiedenen Tabellen je nach Version.
    # Zusätzlich erkennen wir ResourceIds die mit 'pb:' oder 'pbb:' beginnen.
    pb_record_ids = set()

    def try_tag_query(table_tags, col_name, table_res, col_tag_id, col_rec_id):
        try:
            cur.execute(f"SELECT Id FROM {table_tags} WHERE LOWER({col_name}) = 'pb'")
            tag_ids = [r[0] for r in cur.fetchall()]
            if not tag_ids:
                return 0
            ph = ','.join('?' * len(tag_ids))
            cur.execute(f"SELECT DISTINCT {col_rec_id} FROM {table_res} WHERE {col_tag_id} IN ({ph})", tag_ids)
            rids = {r[0] for r in cur.fetchall()}
            pb_record_ids.update(rids)
            return len(rids)
        except Exception as e:
            return 0

    # Variante 1: Tags / ResourceTags
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('Tags','ResourceTags')")
    found_tables = {r[0] for r in cur.fetchall()}
    if 'Tags' in found_tables and 'ResourceTags' in found_tables:
        cur.execute("PRAGMA table_info(Tags)")
        tag_cols = {r[1] for r in cur.fetchall()}
        name_col = next((c for c in ['Name','Label','TagName'] if c in tag_cols), None)
        if name_col:
            n = try_tag_query('Tags', name_col, 'ResourceTags', 'TagId', 'RecordId')
            if n: print(f"✅ Tag 'pb' gefunden via Tags/ResourceTags: {n} Bücher")

    # Variante 2: UserTags / UserTagResources
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('UserTags','UserTagResources')")
    found_tables2 = {r[0] for r in cur.fetchall()}
    if 'UserTags' in found_tables2 and 'UserTagResources' in found_tables2:
        cur.execute("PRAGMA table_info(UserTags)")
        utag_cols = {r[1] for r in cur.fetchall()}
        name_col2 = next((c for c in ['Name','Label','TagName'] if c in utag_cols), None)
        if name_col2:
            n2 = try_tag_query('UserTags', name_col2, 'UserTagResources', 'UserTagId', 'RecordId')
            if n2: print(f"✅ Tag 'pb' gefunden via UserTags/UserTagResources: {n2} Bücher")

    if pb_record_ids:
        print(f"✅ Gesamt {len(pb_record_ids)} Bücher mit Logos-Tag 'pb' erkannt")
    else:
        print("ℹ️  Kein Logos-Tag 'pb' in DB gefunden – erkenne Personal Books nur über ResourceId-Präfix (pb:/pbb:)")

    if has_sg:
        cur.execute(f"""
            SELECT r.RecordId, r.ResourceId, r.Title, r.Authors,
                   GROUP_CONCAT(DISTINCT sg.Name, '; ') as SubjectGroups, r.Series
            FROM Records r
            LEFT JOIN ResourceSubjectGroups rsg ON r.RecordId = rsg.RecordId
            LEFT JOIN SubjectGroups sg ON rsg.SubjectGroupId = sg.Id
            WHERE r.Title IS NOT NULL AND r.ResourceId IS NOT NULL {owned_filter}
            GROUP BY r.RecordId
        """)
    else:
        cur.execute(f"""
            SELECT r.RecordId, r.ResourceId, r.Title, r.Authors, NULL, r.Series
            FROM Records r
            WHERE r.Title IS NOT NULL AND r.ResourceId IS NOT NULL {owned_filter}
        """)

    books = cur.fetchall()
    conn.close()
    print(f"📚 {len(books):,} Bücher geladen")
    
    # ═══════════════════════════════════════════════════════════
    # PHASE 1: SERIES-ANALYSE
    # ═══════════════════════════════════════════════════════════
    series_analysis = analyze_series(books)
    
    categorized = {cat: [] for cat in CATEGORIES}
    # Rohdaten für Diagnose: Liste von (title, resource_id, subj, authors, series)
    sonstige_raw = []

    for rec_id, res_id, title, authors, subj, series in books:
        # Prüfe ob Buch per Logos-Tag "pb" oder ResourceId-Präfix als Personal Book markiert ist
        rid_lower = (res_id or '').lower()
        is_personal = (
            rec_id in pb_record_ids or
            rid_lower.startswith('pb:') or
            rid_lower.startswith('pbb:')
        )
        if is_personal:
            cat = 'Persönliche Bücher'
        else:
            cat = categorize_book(title, res_id, subj, authors, series, series_analysis)
        entry = {
            'r': res_id,
            't': title,
            'a': authors or '',
            's': series or '',  # SERIES-FELD für Sidebar-Themes!
            'c': f"covers/{(res_id or '').replace(':', '_').replace('/', '_')}.jpg",
            'record_id': rec_id
        }
        target = cat or 'Sonstige'
        if target == 'Sonstige':
            sonstige_raw.append((title or '', res_id or '', subj or '', authors or '', series or ''))
        categorized[target].append(entry)

    # Statistik ausgeben
    print(f"\n📊 Kategorisierungsergebnis:")
    for cat, books_list in sorted(categorized.items(), key=lambda x: -len(x[1])):
        if books_list:
            print(f"   {cat}: {len(books_list):,}")
    print(f"\n⚠️  Nicht kategorisiert (Sonstige): {len(sonstige_raw):,}")

    # Rohdaten für Diagnose anhängen
    categorized['_sonstige_raw'] = sonstige_raw
    return categorized

# ============================================================
# GRUPPEN ERSTELLEN
# ============================================================
def create_groups(books, max_per=25, target_per_group=90):
    """
    Erstellt intelligente alphabetische Gruppen.
    - Bei <100 Büchern: Keine Gruppierung
    - Bei >=100 Büchern: Dynamische Buchstaben-Ranges (A-C, D-F, etc.) 
      mit Ziel von ~80-100 Büchern pro Gruppe
    - Fügt 'letter_breaks' hinzu für visuelle Trennlinien im Regal
    """
    if not books:
        return []
    
    # Bei <100 Büchern: Keine Gruppierung
    if len(books) < 100:
        return [{'name': 'Alle', 'books': books}]
    
    # Sortiere und zähle Bücher pro Buchstabe
    from collections import defaultdict
    letter_counts = defaultdict(list)
    
    for book in books:
        title = book['t'] or ''
        fc = title[0].upper() if title else '?'
        letter = '1-9' if fc.isdigit() else (fc if fc.isalpha() else '?')
        letter_counts[letter].append(book)
    
    # Erstelle dynamische Gruppen mit ~80-100 Büchern
    groups = []
    current_group_books = []
    current_group_letters = []
    
    # Sortiere Buchstaben (1-9 zuerst, dann alphabetisch)
    sorted_letters = sorted(letter_counts.keys(), 
                           key=lambda x: ('0' if x == '1-9' else '1' if x == '?' else '2') + x)
    
    for letter in sorted_letters:
        letter_books = letter_counts[letter]
        
        # Wenn Hinzufügen dieser Bücher die Gruppe zu groß macht UND wir schon Bücher haben
        if current_group_books and len(current_group_books) + len(letter_books) > target_per_group:
            # Speichere aktuelle Gruppe
            group_name = current_group_letters[0] if len(current_group_letters) == 1 else f"{current_group_letters[0]}-{current_group_letters[-1]}"
            
            # Füge letter_breaks für visuelle Trennungen hinzu
            books_with_breaks = []
            last_letter = None
            for book in current_group_books:
                book_letter = (book['t'] or '')[0].upper() if book.get('t') else '?'
                if book_letter.isdigit():
                    book_letter = '1-9'
                elif not book_letter.isalpha():
                    book_letter = '?'
                
                if last_letter and last_letter != book_letter:
                    books_with_breaks.append({'_letter_break': book_letter})
                books_with_breaks.append(book)
                last_letter = book_letter
            
            groups.append({'name': group_name, 'books': books_with_breaks})
            
            # Starte neue Gruppe
            current_group_books = []
            current_group_letters = []
        
        # Füge Buchstaben zur aktuellen Gruppe hinzu
        current_group_letters.append(letter)
        current_group_books.extend(letter_books)
    
    # Letzte Gruppe hinzufügen
    if current_group_books:
        group_name = current_group_letters[0] if len(current_group_letters) == 1 else f"{current_group_letters[0]}-{current_group_letters[-1]}"
        
        books_with_breaks = []
        last_letter = None
        for book in current_group_books:
            book_letter = (book['t'] or '')[0].upper() if book.get('t') else '?'
            if book_letter.isdigit():
                book_letter = '1-9'
            elif not book_letter.isalpha():
                book_letter = '?'
            
            if last_letter and last_letter != book_letter:
                books_with_breaks.append({'_letter_break': book_letter})
            books_with_breaks.append(book)
            last_letter = book_letter
        
        groups.append({'name': group_name, 'books': books_with_breaks})
    
    return groups

# ============================================================
# DATA.JS ERSTELLEN
# ============================================================
def split_journal_series(books):
    """
    Gruppiert Journal-Bücher nach Seriennamen.
    Strategie:
      1. Nutze b['ser'] (Logos Series-Feld) falls vorhanden.
      2. Fallback: Regex extrahiert Reihenname vor Band-/Heft-Nummer.
      3. Kein Muster gefunden: kompletter Titel = Reihenname
         (z.B. "9Marks Journal" ohne Bandnummer → alle Hefte eine Reihe).
      Qumran-Handschriften (1Q, 4Q...) werden herausgefiltert.
    """
    import re
    MANUSCRIPT_RE = re.compile(r'^\d{1,2}Q\d|^Biblical Dead Sea', re.IGNORECASE)
    series_map = {}
    for b in books:
        title = (b.get('t') or '').strip()
        if MANUSCRIPT_RE.match(title):
            continue  # Qumran-Handschriften nicht in Journale
        # 1. Logos Series-Feld (zuverlässigste Quelle)
        series_name = (b.get('ser') or '').strip()
        if not series_name:
            # 2. Regex: Nummer/Jahrgang am Ende abschneiden
            m = re.search(
                r'(.+?)[\s,;:]+(?:vol\.?|volume|no\.?|number|issue|bd\.?|band|nr\.?|'
                r'heft|jahrgang|jg\.?|\d{4}|\d+\s*[/\-\u2013]\s*\d+|\d+)\s*[\d\s/\-\u2013]*$',
                title, re.IGNORECASE
            )
            if m:
                series_name = m.group(1).strip().rstrip('.,;:\u2013-').strip()
            else:
                # 3. Kein Muster → ganzer Titel ist Reihenname
                # "9Marks Journal", "Christianity Today" etc. landen korrekt zusammen
                series_name = title
        if not series_name:
            series_name = '__einzeln'
        if series_name not in series_map:
            series_map[series_name] = []
        series_map[series_name].append(b)
    return series_map


def create_data_js(categorized, out_path):
    # Journal-Aufteilung wird jetzt durch Series-Analyse in load_books() gemacht
    
    library_data = {}
    for cat, books in categorized.items():
        if cat.startswith('_') or not books:
            continue
        books.sort(key=lambda b: b['t'] or '')
        library_data[cat] = [{'name': 'Alle', 'groups': create_groups(books)}]
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write('const LIBRARY_DATA = ')
        json.dump(library_data, f, ensure_ascii=False, indent=2)
        f.write(';\n')
    print(f"✅ data.js erstellt ({os.path.getsize(out_path) // 1024} KB)")

# ============================================================
# COVER EXTRAHIEREN
# ============================================================
def extract_covers(db_path, out_dir, categorized):
    covers_dir = os.path.join(out_dir, 'covers')
    os.makedirs(covers_dir, exist_ok=True)

    print("  📋 Erstelle Index...")
    rec_to_res = {}
    for key, books in categorized.items():
        if key.startswith('_'):
            continue  # _sonstige_raw und andere Hilfseinträge überspringen
        for b in books:
            if b.get('record_id'):
                rec_to_res[b['record_id']] = b['r']

    record_ids = list(rec_to_res.keys())
    print(f"  🖼️  Extrahiere {len(record_ids):,} Cover...")
    if not record_ids:
        print("  ℹ️  Keine Cover zu extrahieren.")
        conn.close()
        return

    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    cur = conn.cursor()
    # Verarbeite in Batches von 500, um SQLite-Variable-Limit (999) zu umgehen
    # (Fix für Bibliotheken mit >999 Buechern: sqlite3.OperationalError: too many SQL variables)
    BATCH_SIZE = 500
    all_rows = []
    for i in range(0, len(record_ids), BATCH_SIZE):
        batch = record_ids[i:i + BATCH_SIZE]
        if not batch:
            continue
        ph = ','.join('?' * len(batch))
        cur.execute(
            f"SELECT RecordId, Image FROM Images WHERE RecordId IN ({ph}) AND Image IS NOT NULL",
            batch
        )
        all_rows.extend(cur.fetchall())

    total_rows = len(all_rows)
    print(f"  🔄 Verarbeite {total_rows:,} Cover-Einträge...")
    extracted = 0
    for rec_id, blob in all_rows:
        res_id = rec_to_res.get(rec_id)
        if not res_id:
            continue
        data, ext = None, None
        if blob[:8] == b'\x89PNG\r\n\x1a\n':
            data, ext = blob, 'png'
        elif blob[:2] == b'\xff\xd8':
            data, ext = blob, 'jpg'
        elif blob[:2] in [b'\x78\x9c', b'\x78\x01']:
            try:
                d = zlib.decompress(blob)
                if d[:8] == b'\x89PNG\r\n\x1a\n':
                    data, ext = d, 'png'
                elif d[:2] == b'\xff\xd8':
                    data, ext = d, 'jpg'
            except:
                pass
        if data:
            safe = res_id.replace(':', '_').replace('/', '_')
            with open(os.path.join(covers_dir, f"{safe}.{ext}"), 'wb') as f:
                f.write(data)
            extracted += 1
        if extracted % 500 == 0 and extracted > 0:
            print(f"  ✅ {extracted:,} Cover extrahiert...")

    conn.close()
    print(f"\n  ✅ {extracted:,} Cover extrahiert - FERTIG!")

# ============================================================
# DATEIEN KOPIEREN
# ============================================================
def copy_files(script_dir, out_dir):
    files = [HTML_FILE, 'app.js', 'styles.css', 'lazy-loader.js',
             'notes.js', 'bible-complete.js', 'exegese-all-in-one.js',
]
    for fn in files:
        src = os.path.join(script_dir, fn)
        if os.path.exists(src):
            shutil.copy2(src, out_dir)
            print(f"  ✅ {fn} kopiert")
        else:
            print(f"  ⚠️  {fn} nicht gefunden")

# ============================================================
# DESKTOP-VERKNÜPFUNG
# ============================================================
def create_shortcut(out_dir):
    system = platform.system()
    # Desktop-Pfad: verschiedene Sprachen/Systeme
    desktop = None
    for candidate in [
        os.path.join(str(Path.home()), 'Desktop'),
        os.path.join(str(Path.home()), 'Schreibtisch'),
        os.path.join(str(Path.home()), 'Bureau'),
        os.path.join(str(Path.home()), 'Escritorio'),
    ]:
        if os.path.isdir(candidate):
            desktop = candidate
            break
    if not desktop:
        # Windows: Registry-Pfad abfragen
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                r'Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders')
            desktop = winreg.QueryValueEx(key, 'Desktop')[0]
            winreg.CloseKey(key)
        except:
            desktop = os.path.join(str(Path.home()), 'Desktop')
    html_path = os.path.join(out_dir, HTML_FILE)
    
    # WICHTIG: Entferne alte 3.0 Verknüpfungen
    old_shortcuts = [
        'LLR Revived 3.0 DE', 'LLR-Revived 3.0 DE', 'LLR Revised 3.0 DE',
        'LLR Revised 3.1 DE', 'LLR-Revised 3.1 DE', 'LLR-Revised-3.1-DE',
        'LLR Revised 3_1 DE', 'LLR-Revised 3_1 DE', 'LLR-Revised-3_1-DE',
        'LLR Revival 3.1 DE', 'LLR-Revival 3.1 DE',
        'LLR-Revived 4.0 DE', 'LLR Revived 4.0 DE',
    ]    
    for old_name in old_shortcuts:
        try:
            if system == "Windows":
                old_sc = os.path.join(desktop, f'{old_name}.url')
            elif system == "Darwin":
                old_sc = os.path.join(desktop, f'{old_name}.webloc')
            else:
                old_sc = os.path.join(desktop, f'{old_name}.desktop')
            
            if os.path.exists(old_sc):
                os.remove(old_sc)
                print(f"🗑️  Alte Verknüpfung entfernt: {old_name}")
        except Exception as e:
            pass  # Ignoriere Fehler beim Löschen alter Verknüpfungen
    
    try:
        if system == "Windows":
            sc = os.path.join(desktop, f'{SHORTCUT_NAME}.url')
            # Immer neu schreiben - überschreibt auch bestehende
            with open(sc, 'w', encoding='utf-8') as f:
                f.write('[InternetShortcut]\n')
                f.write(f'URL=file:///{html_path.replace(os.sep, "/")}\n')
        elif system == "Darwin":
            sc = os.path.join(desktop, f'{SHORTCUT_NAME}.webloc')
            with open(sc, 'w', encoding='utf-8') as f:
                f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
                f.write('<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n')
                f.write('<plist version="1.0"><dict><key>URL</key>\n')
                f.write(f'<string>file://{html_path}</string></dict></plist>\n')
        else:
            sc = os.path.join(desktop, f'{SHORTCUT_NAME}.desktop')
            with open(sc, 'w', encoding='utf-8') as f:
                f.write('[Desktop Entry]\nVersion=1.0\nType=Link\n')
                f.write(f'Name={SHORTCUT_NAME}\n')
                f.write(f'URL=file://{html_path}\nIcon=text-html\n')
            os.chmod(sc, 0o755)
        print(f"🔗 Desktop-Verknüpfung erstellt: {sc}")
    except Exception as e:
        print(f"⚠️  Verknüpfung konnte nicht erstellt werden: {e}")

# ============================================================
# DIAGNOSE: SONSTIGE ANALYSIEREN
# ============================================================
def create_diagnose(categorized, out_dir):
    """
    Erstellt sonstige-analyse.txt mit:
    - Vollständiger Liste aller Sonstige-Bücher (Titel, ResourceId, SubjectGroups)
    - Top-50 häufigste SubjectGroup-Typen (für neue Keywords)
    - Top-50 häufigste Wörter in Titeln (für neue Keywords)
    - Top-50 häufigste ResourceId-Prefixe
    """
    sonstige_raw = categorized.get('_sonstige_raw', [])
    if not sonstige_raw:
        return

    out_path = os.path.join(out_dir, 'sonstige-analyse.txt')

    # SubjectGroup-Häufigkeiten zählen
    subj_counter = collections.Counter()
    for _, _, subj, _, _ in sonstige_raw:
        if subj:
            for part in subj.split(';'):
                s = part.strip()
                if s:
                    subj_counter[s] += 1

    # Titel-Wort-Häufigkeiten (>3 Zeichen, keine Stoppwörter)
    stopwords = {
        'the', 'and', 'for', 'with', 'from', 'that', 'this', 'are', 'was', 'has',
        'have', 'will', 'not', 'but', 'its', 'our', 'your', 'their', 'which',
        'eine', 'einer', 'eines', 'einem', 'einen', 'der', 'die', 'das', 'des',
        'den', 'dem', 'ein', 'und', 'oder', 'von', 'zur', 'zum', 'bei', 'mit',
        'nach', 'über', 'unter', 'auf', 'aus', 'als', 'auch', 'sich', 'durch',
        'werden', 'wurde', 'sein', 'ist', 'sind', 'wird', 'kann', 'nur', 'noch',
        'del', 'los', 'las', 'una', 'por', 'para', 'con', 'que', 'les', 'des',
        'dans', 'pour', 'par', 'sur', 'une', 'aux'
    }
    word_counter = collections.Counter()
    for title, _, _, _, _ in sonstige_raw:
        for word in title.lower().split():
            w = word.strip('.,;:!?()[]{}"\'-')
            if len(w) > 3 and w not in stopwords and not w.isdigit():
                word_counter[w] += 1

    # ResourceId-Prefix-Häufigkeiten
    prefix_counter = collections.Counter()
    for _, res_id, _, _, _ in sonstige_raw:
        if ':' in res_id:
            prefix_counter[res_id.split(':')[0]] += 1
        elif '.' in res_id:
            prefix_counter[res_id.split('.')[0]] += 1
        else:
            prefix_counter[res_id[:8] if len(res_id) >= 8 else res_id] += 1

    # Serien-Häufigkeiten
    series_counter = collections.Counter()
    for _, _, _, _, series in sonstige_raw:
        if series and series.strip():
            series_counter[series.strip()] += 1

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        f.write(f"DIAGNOSE: SONSTIGE-BÜCHER ({len(sonstige_raw):,} Einträge)\n")
        f.write("LLR-Revival 4.0 - Logos Library Reporter Revival\n")
        f.write("Zweck: Identifikation fehlender Keywords für bessere Kategorisierung\n")
        f.write("=" * 80 + "\n\n")

        # ── TOP SubjectGroups ──
        f.write("=" * 80 + "\n")
        f.write(f"TOP {min(80, len(subj_counter))} SUBJECTGROUP-TYPEN IN 'SONSTIGE'\n")
        f.write("(Diese Typen sollten ggf. einer Kategorie zugeordnet werden)\n")
        f.write("=" * 80 + "\n")
        for sg, count in subj_counter.most_common(80):
            f.write(f"  {count:5d}x  {sg}\n")
        f.write("\n")

        # ── TOP Titel-Wörter ──
        f.write("=" * 80 + "\n")
        f.write(f"TOP {min(100, len(word_counter))} HÄUFIGSTE WÖRTER IN SONSTIGE-TITELN\n")
        f.write("(Wörter mit hoher Häufigkeit = potenzielle neue Keywords)\n")
        f.write("=" * 80 + "\n")
        for word, count in word_counter.most_common(100):
            f.write(f"  {count:5d}x  {word}\n")
        f.write("\n")

        # ── TOP ResourceId-Prefixe ──
        f.write("=" * 80 + "\n")
        f.write(f"TOP {min(50, len(prefix_counter))} RESOURCEID-PREFIXE IN 'SONSTIGE'\n")
        f.write("(Zeigt welche Logos-Ressourcentypen nicht erkannt werden)\n")
        f.write("=" * 80 + "\n")
        for prefix, count in prefix_counter.most_common(50):
            f.write(f"  {count:5d}x  {prefix}\n")
        f.write("\n")

        # ── TOP Serien ──
        f.write("=" * 80 + "\n")
        f.write(f"TOP {min(50, len(series_counter))} SERIEN IN 'SONSTIGE'\n")
        f.write("(Serien die keiner Kategorie zugeordnet wurden)\n")
        f.write("=" * 80 + "\n")
        for series, count in series_counter.most_common(50):
            f.write(f"  {count:5d}x  {series}\n")
        f.write("\n")

        # ── Vollständige Bücherliste ──
        f.write("=" * 80 + "\n")
        f.write(f"VOLLSTÄNDIGE LISTE ALLER {len(sonstige_raw):,} SONSTIGE-BÜCHER\n")
        f.write("Format: TITEL  |  ResourceId  |  SubjectGroups  |  Serie\n")
        f.write("=" * 80 + "\n")
        for title, res_id, subj, authors, series in sorted(sonstige_raw, key=lambda x: x[0].lower()):
            f.write(f"{title}\n")
            f.write(f"    ID:      {res_id}\n")
            if subj:
                f.write(f"    Typen:   {subj}\n")
            if series:
                f.write(f"    Serie:   {series}\n")
            if authors:
                f.write(f"    Autor:   {authors[:80]}\n")
            f.write("\n")

    size_kb = os.path.getsize(out_path) // 1024
    print(f"\n🔍 DIAGNOSE erstellt: sonstige-analyse.txt ({size_kb} KB)")
    print(f"   → Bitte diese Datei an Claude AI schicken für bessere Kategorisierung!")
    print(f"   → Pfad: {out_path}")





# ============================================================
# HAUPTPROGRAMM
# ============================================================
def main():
    print(HEADER)
    print("🔍 Suche Logos/Verbum Installation...")
    catalogs = find_catalogs()
    if not catalogs:
        print("❌ Keine Logos/Verbum-Installation gefunden!")
        return
    db_path = os.path.join(catalogs[0], 'catalog.db')
    print(f"✅ Gefunden: {catalogs[0]}")

    out_dir = os.path.join(str(Path.home()), 'Desktop', 'LLR-Revival-4.0-DE')
    os.makedirs(out_dir, exist_ok=True)
    print(f"📁 Ausgabe: {out_dir}")

    print("\n📚 Lade und kategorisiere Bücher...")
    categorized = load_books(db_path)

    print("\n💾 Erstelle data.js...")
    create_data_js(categorized, os.path.join(out_dir, 'data.js'))

    print("\n🔍 Erstelle Diagnose-Datei...")
    create_diagnose(categorized, out_dir)

    print("\n🖼️  Extrahiere Cover...")
    extract_covers(db_path, out_dir, categorized)

    print("\n📋 Kopiere Programmdateien...")
    script_dir = os.path.dirname(os.path.abspath(__file__))
    copy_files(script_dir, out_dir)

    create_shortcut(out_dir)

    print(f"\n✅ INSTALLATION ERFOLGREICH!")

    print("   📦 NEU: Export-Button jetzt in jedem Buch-Detail verfügbar!")
    print("       Buch anklicken → '💾 Buch exportieren' Button → Export-Assistent")
    print(f"   Öffnen Sie: {os.path.join(out_dir, HTML_FILE)}")
    print(f"   Oder nutzen Sie die Desktop-Verknüpfung: '{SHORTCUT_NAME}'")

if __name__ == '__main__':
    main()

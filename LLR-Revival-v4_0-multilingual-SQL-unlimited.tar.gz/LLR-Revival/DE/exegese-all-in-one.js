// Exegese-all-in-one.js - Platzhalter
console.log('✅ exegese-all-in-one.js geladen (Platzhalter)');

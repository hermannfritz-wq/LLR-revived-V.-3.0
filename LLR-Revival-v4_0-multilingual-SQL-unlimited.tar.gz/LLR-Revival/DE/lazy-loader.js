// ============================================
// ADVANCED LAZY LOADER FÜR LOGOS-BIBLIOTHEK
// ============================================
// Dieser Loader optimiert das Laden großer Datenmengen

(function() {
    'use strict';
    
    // Loader-Status anzeigen
    function showLoader(message) {
        const existingLoader = document.getElementById('advancedLoader');
        if (existingLoader) {
            existingLoader.querySelector('.loader-message').textContent = message;
            return;
        }
        
        const loader = document.createElement('div');
        loader.id = 'advancedLoader';
        loader.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(44, 24, 16, 0.95);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 99999;
            font-family: 'Georgia', serif;
        `;
        
        loader.innerHTML = `
            <div style="text-align: center;">
                <div style="width: 80px; height: 80px; border: 5px solid rgba(212, 175, 55, 0.3); border-top: 5px solid #d4af37; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 20px;"></div>
                <h2 style="color: #d4af37; font-size: 1.8em; margin-bottom: 10px; text-shadow: 0 2px 4px rgba(0,0,0,0.5);">📚 Laden...</h2>
                <p class="loader-message" style="color: #f4e4c1; font-size: 1.1em;">${message}</p>
                <div class="progress-bar" style="width: 300px; height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; margin: 20px auto; overflow: hidden;">
                    <div class="progress-fill" style="width: 0%; height: 100%; background: linear-gradient(90deg, #d4af37, #f4e4c1); transition: width 0.3s;"></div>
                </div>
            </div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;
        
        document.body.appendChild(loader);
    }
    
    function updateProgress(percent, message) {
        const loader = document.getElementById('advancedLoader');
        if (loader) {
            const progressFill = loader.querySelector('.progress-fill');
            const messageEl = loader.querySelector('.loader-message');
            if (progressFill) progressFill.style.width = percent + '%';
            if (messageEl && message) messageEl.textContent = message;
        }
    }
    
    function hideLoader() {
        const loader = document.getElementById('advancedLoader');
        if (loader) {
            loader.style.opacity = '0';
            loader.style.transition = 'opacity 0.5s';
            setTimeout(() => loader.remove(), 500);
        }
    }
    
    // Lazy Loading Manager
    const LazyLoadManager = {
        scriptsToLoad: [
            { src: 'data.js', name: 'Bibliotheksdaten', priority: 1, progress: 0 },
            { src: 'bible-complete.js', name: 'Bibeltexte', priority: 2, progress: 20 },
            { src: 'exegese-all-in-one.js', name: 'Exegese-Tools', priority: 3, progress: 50 },
            { src: 'notes.js', name: 'Notizen-System', priority: 4, progress: 70 },
            { src: 'app.js?v=' + Date.now(), name: 'Hauptanwendung', priority: 5, progress: 85 }
        ],
        
        loadedCount: 0,
        totalScripts: 0,
        
        init: function() {
            this.totalScripts = this.scriptsToLoad.length;
            showLoader('Initialisiere Bibliothek...');
            this.loadNextScript();
        },
        
        loadNextScript: function() {
            if (this.loadedCount >= this.totalScripts) {
                updateProgress(100, 'Fertig!');
                // Intro sofort zeigen, Loader parallel ausblenden
                if (typeof showIntroSplash === 'function') showIntroSplash();
                setTimeout(hideLoader, 300);
                return;
            }
            
            const scriptInfo = this.scriptsToLoad[this.loadedCount];
            updateProgress(scriptInfo.progress, `Lade ${scriptInfo.name}...`);
            
            const script = document.createElement('script');
            script.src = scriptInfo.src;
            script.async = false; // Sequentielles Laden
            
            script.onload = () => {
                this.loadedCount++;
                const isLast = this.loadedCount >= this.totalScripts;
                console.log(`✅ ${scriptInfo.name} geladen (${this.loadedCount}/${this.totalScripts})`);
                this.loadNextScript();
                if (isLast && typeof init === 'function') init();
            };
            
            script.onerror = () => {
                console.error(`❌ Fehler beim Laden von ${scriptInfo.name}`);
                if (scriptInfo.src === 'data.js') {
                    // data.js fehlt → Installer noch nicht ausgeführt
                    document.body.innerHTML = '<div style="position:fixed;top:0;left:0;right:0;bottom:0;background:#2c1810;display:flex;align-items:center;justify-content:center;font-family:Georgia,serif">' +
                        '<div style="max-width:560px;text-align:center;padding:40px;background:#3a2010;border-radius:16px;border:2px solid #d4af37;color:#f4e4c1">' +
                        '<div style="font-size:3em;margin-bottom:16px">📚</div>' +
                        '<h2 style="color:#d4af37;margin-bottom:16px">LLR-Revival 4.0</h2>' +
                        '<p style="font-size:1.15em;margin-bottom:24px;line-height:1.6">' +
                        '🇩🇪 Bitte zuerst den Installer starten:<br><strong>01-INSTALLIEREN-Doppelklick.py</strong><br><br>' +
                        '🇬🇧 Please run the installer first:<br><strong>02-INSTALL-DoubleClick-EN.py</strong><br><br>' +
                        '🇫🇷 Veuillez d\'abord lancer l\'installateur:<br><strong>03-INSTALLER-DoubleClic-FR.py</strong><br><br>' +
                        '🇪🇸 Por favor ejecute primero el instalador:<br><strong>04-INSTALAR-DobleClick-ES.py</strong></p>' +
                        '<p style="color:#9d8567;font-size:0.9em">→ INSTALLATION-DE.txt / EN / FR / ES lesen</p>' +
                        '</div></div>';
                } else {
                    this.loadedCount++;
                    this.loadNextScript();
                }
            };
            
            document.head.appendChild(script);
        }
    };
    
    // Intersection Observer für Lazy Loading von Bildern
    const ImageLazyLoader = {
        init: function() {
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            if (img.dataset.src) {
                                img.src = img.dataset.src;
                                img.removeAttribute('data-src');
                                observer.unobserve(img);
                            }
                        }
                    });
                }, {
                    rootMargin: '50px'
                });
                
                // Observer auf alle Bilder mit data-src anwenden
                document.addEventListener('DOMContentLoaded', () => {
                    document.querySelectorAll('img[data-src]').forEach(img => {
                        imageObserver.observe(img);
                    });
                });
                
                // Für dynamisch hinzugefügte Bilder
                window.observeLazyImage = function(img) {
                    if (img.dataset.src) {
                        imageObserver.observe(img);
                    }
                };
            } else {
                // Fallback für ältere Browser
                document.addEventListener('DOMContentLoaded', () => {
                    document.querySelectorAll('img[data-src]').forEach(img => {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    });
                });
            }
        }
    };
    
    // Performance Monitoring
    const PerformanceMonitor = {
        startTime: performance.now(),
        
        logMetrics: function() {
            const loadTime = performance.now() - this.startTime;
            console.log(`📊 Performance Metriken:`);
            console.log(`   Gesamtladezeit: ${(loadTime / 1000).toFixed(2)}s`);
            
            if (window.performance && window.performance.memory) {
                const memory = window.performance.memory;
                console.log(`   Speichernutzung: ${(memory.usedJSHeapSize / 1048576).toFixed(2)} MB`);
            }
            
            if (window.LIBRARY_DATA) {
                const categories = Object.keys(window.LIBRARY_DATA).filter(k => k !== '_meta').length;
                console.log(`   Kategorien geladen: ${categories}`);
            }
        }
    };
    
    // Starte Lazy Loading beim DOMContentLoaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            LazyLoadManager.init();
            ImageLazyLoader.init();
            
            // Performance-Metriken nach vollständigem Laden
            window.addEventListener('load', () => {
                setTimeout(() => {
                    PerformanceMonitor.logMetrics();
                }, 1000);
            });
        });
    } else {
        LazyLoadManager.init();
        ImageLazyLoader.init();
    }
    
    // Expose nützliche Funktionen global
    window.LazyLoadManager = LazyLoadManager;
    window.ImageLazyLoader = ImageLazyLoader;
    
})();


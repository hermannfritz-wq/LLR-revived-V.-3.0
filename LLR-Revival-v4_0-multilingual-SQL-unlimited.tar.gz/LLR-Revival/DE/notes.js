// Notes.js - Platzhalter
console.log('✅ notes.js geladen (Platzhalter)');

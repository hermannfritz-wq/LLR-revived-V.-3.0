# LLR-REVIVAL 4.0 – QUICK OVERVIEW

## What is this?

LLR-Revival 4.0 is a browser-based library explorer for
Logos Bible Software and Verbum. It displays your theological books
in a clearly organized, categorized view and enables searching,
notes, reading plans, related resources, and web research for each book.

Inspired by Steve Clark's Logos Library Reporter (2015).
https://www.l4libreport.clark-tx.net/

## Quick Start

1. Double-click: 01-INSTALL-DoubleClick.py
2. Open in browser: LLR-Revival-4.0-EN.html

## Supported Operating Systems

- Windows 10/11 (fully tested)
- macOS 12+ (Logos runs natively on Mac)
- Linux (Logos via Wine or Bottles)

## Requirements

- Python 3.8+  →  https://www.python.org/downloads/
- Logos Bible Software (launched at least once)
- Chrome, Firefox or Edge

## Languages

Deutsch · English · Français · Español
(Language selection in the top right of the program)

## License

Open-Source · Free use explicitly permitted
No sale or commercial use allowed
Attribution: © 2026 Pastor Hermann Fritz, Germany

## Detailed Help

→ Unzip Dokumentation.zip
→ Read 00-START-HERE.txt
→ Open INSTALLATION-HILFE.html

---
Version: 4.0 | March 2026 | © Pastor Hermann Fritz

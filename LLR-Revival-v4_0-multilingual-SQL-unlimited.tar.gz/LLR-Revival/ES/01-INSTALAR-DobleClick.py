#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLR-Revival 4.0 ES - INSTALLER MIT AUTOMATISCHEM BUGFIX
================================================================
Dieses Skript ruft das Original-Installationsskript auf UND
wendet automatisch den Spanish Bible Hint Bugfix an.

NUTZER MUSS NUR DOPPELKLICK MACHEN - FERTIG!
"""

import sys
import os
import subprocess
import shutil
from pathlib import Path

print("""
╔═══════════════════════════════════════════════════════════════╗
║    LLR-REVIVAL 4.0 - INSTALACIÓN (ESPAÑOL)                    ║
║    CON BUGFIX AUTOMÁTICO: Spanish Bible Hint                  ║
╚═══════════════════════════════════════════════════════════════╝

📦 Este instalador incluye:
   ✓ Instalación completa de LLR Revival 4.0
   ✓ BUGFIX automático para avisos de Biblia española
   
🚀 Simplemente espere - todo es automático!

""")

# Hole das Skript-Verzeichnis
SCRIPT_DIR = Path(__file__).parent

# Pfade
ORIGINAL_INSTALLER = SCRIPT_DIR / "ORIGINAL-01-INSTALAR-DobleClick.py"
BUGFIX_DIR = SCRIPT_DIR / "BUGFIX-Spanish-Bible-Hint"
PYTHON_HEREDOC = BUGFIX_DIR / "python_heredoc.py"
SCRIPT_FILE = BUGFIX_DIR / "Skript"

# ===================================================================
# SCHRITT 1: Original-Installation ausführen
# ===================================================================

print("━" * 65)
print("PASO 1: Ejecutando instalación original de LLR Revival...")
print("━" * 65)

try:
    # Führe das Original-Installationsskript aus
    result = subprocess.run(
        [sys.executable, str(ORIGINAL_INSTALLER)],
        cwd=str(SCRIPT_DIR)
    )
    
    if result.returncode != 0:
        print("\n⚠ La instalación original terminó con advertencias")
        print("   Continuando con bugfix de todos modos...")
    else:
        print("\n✅ Instalación original completada")
        
except Exception as e:
    print(f"\n❌ ERROR durante instalación original: {e}")
    input("\nPresione ENTER para salir...")
    sys.exit(1)

# ===================================================================
# SCHRITT 2: Bugfix anwenden
# ===================================================================

print("\n" + "━" * 65)
print("PASO 2: Aplicando BUGFIX Spanish Bible Hint...")
print("━" * 65)

# Finde die erstellte HTML-Datei auf dem Desktop
desktop = Path.home() / "Desktop"
output_dir = desktop / "LLR-Revival-4.0-DE"  # Das Original-Skript erstellt diesen Ordner

if not output_dir.exists():
    # Versuche alternative Pfade
    for alt_name in ["LLR-Revival-4.0-ES", "LLR-Revival-4.0", "LLR-Revival"]:
        alt_path = desktop / alt_name
        if alt_path.exists():
            output_dir = alt_path
            break

if not output_dir.exists():
    print(f"\n⚠ No se encontró el directorio de salida en: {output_dir}")
    print("   El bugfix debe aplicarse manualmente")
    print("   Consulte BUGFIX-Spanish-Bible-Hint/SCHNELLANLEITUNG.txt")
    input("\nPresione ENTER para salir...")
    sys.exit(0)

print(f"✓ Directorio encontrado: {output_dir}")

# Finde die HTML-Datei
html_files = list(output_dir.glob("LLR-Revival-*.html"))
if not html_files:
    html_files = list(output_dir.glob("*.html"))

if not html_files:
    print("\n⚠ No se encontró archivo HTML")
    print("   El bugfix debe aplicarse manualmente")
    input("\nPresione ENTER para salir...")
    sys.exit(0)

html_file = html_files[0]
print(f"✓ HTML encontrado: {html_file.name}")

# Lese die Bugfix-Dateien
if not PYTHON_HEREDOC.exists() or not SCRIPT_FILE.exists():
    print("\n❌ ERROR: Archivos de bugfix no encontrados!")
    print(f"   Esperado en: {BUGFIX_DIR}")
    input("\nPresione ENTER para salir...")
    sys.exit(1)

with open(PYTHON_HEREDOC, 'r', encoding='utf-8') as f:
    python_code = f.read()

with open(SCRIPT_FILE, 'r', encoding='utf-8') as f:
    script_template = f.read()

print("✓ Archivos de bugfix cargados")

# Lese die HTML-Datei
with open(html_file, 'r', encoding='utf-8') as f:
    html_content = f.read()

# Prüfe ob Bugfix schon angewendet wurde
if 'spanish_bible_hint' in html_content or 'BUGFIX-SPANISH-BIBLE' in html_content:
    print("\n✓ Bugfix ya está aplicado - omitiendo...")
else:
    # Füge den Bugfix-Code ins HTML ein
    bugfix_marker = "<!-- BUGFIX-SPANISH-BIBLE: AUTO-INJECTED CODE -->"
    
    bugfix_code = f"""{bugfix_marker}
<script>
// ========== BUGFIX: Spanish Bible Detection ==========
// Prüft ob Nutzer eine spanische Bibel hat und zeigt Warnung
{python_code.replace('</script>', '<\\/script>')}
</script>
"""
    
    # Füge nach dem <head> Tag ein
    if '<head>' in html_content:
        html_content = html_content.replace('<head>', f'<head>\n{bugfix_code}', 1)
    elif '<html>' in html_content:
        html_content = html_content.replace('<html>', f'<html>\n{bugfix_code}', 1)
    else:
        # Füge am Anfang ein
        html_content = bugfix_code + '\n' + html_content
    
    # Schreibe die modifizierte HTML zurück
    with open(html_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print("✓ Bugfix inyectado en HTML")

# Kopiere auch die Dokumentation
docs_dest = output_dir / "BUGFIX-DOCS"
if not docs_dest.exists():
    shutil.copytree(BUGFIX_DIR, docs_dest)
    print(f"✓ Documentación copiada a: {docs_dest}")

# ===================================================================
# FERTIG!
# ===================================================================

print("\n" + "=" * 65)
print("✅ ¡INSTALACIÓN COMPLETADA CON ÉXITO!")
print("=" * 65)
print(f"""
📁 Ubicación: {output_dir}
📄 Archivo HTML: {html_file.name}

✨ BUGFIX APLICADO:
   → Detección automática de Biblia española
   → Aviso amarillo si no hay Biblia española instalada
   → Enlaces para configurar o comprar Biblia

🎯 PRÓXIMOS PASOS:
   1. Abra el archivo HTML en su navegador
   2. Pruebe el versículo del día español
   3. Si no tiene Biblia española, verá el aviso

📚 Documentación adicional:
   {docs_dest}

""")

input("Presione ENTER para salir...")

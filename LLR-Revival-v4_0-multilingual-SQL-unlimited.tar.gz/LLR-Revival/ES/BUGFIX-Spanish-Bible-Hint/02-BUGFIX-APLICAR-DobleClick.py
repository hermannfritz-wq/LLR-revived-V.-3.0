#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLR-Revival 4.0 - BUGFIX AUTOMÁTICO: Spanish Bible Hint
Aplica automáticamente el bugfix para mostrar avisos cuando no hay Biblia española

Este script modifica la instalación de LLR Revival para incluir:
1. Python heredoc para detectar Biblias españolas
2. Script actualizado con función de aviso
3. Integración automática en la base de datos de Logos
"""

import sys
import os
import shutil
import platform
import sqlite3
import json
import zlib
from pathlib import Path

print("""
╔═══════════════════════════════════════════════════════════════╗
║  LLR-REVIVAL 4.0 - BUGFIX AUTOMÁTICO                          ║
║  Spanish Bible Hint - Instalación Automática                  ║
╚═══════════════════════════════════════════════════════════════╝

Este script aplica el bugfix que muestra un aviso cuando
un usuario sin Biblia española hace clic en el versículo del día.

""")

# ============================================================
# CONFIGURACIÓN
# ============================================================

BUGFIX_DIR = Path(__file__).parent / "BUGFIX-Spanish-Bible-Hint"
PYTHON_HEREDOC_FILE = BUGFIX_DIR / "python_heredoc.py"
SCRIPT_FILE = BUGFIX_DIR / "Skript"

# ============================================================
# DETECCIÓN DE LOGOS
# ============================================================

def find_logos_db():
    """Encuentra la base de datos de Logos"""
    system = platform.system()
    
    if system == "Windows":
        appdata = os.getenv('LOCALAPPDATA')
        search_paths = [
            Path(appdata) / "Logos" / "Data",
            Path(appdata) / "Logos4" / "Data",
        ]
    elif system == "Darwin":  # macOS
        home = Path.home()
        search_paths = [
            home / "Library" / "Application Support" / "Logos" / "Data",
            home / "Library" / "Application Support" / "Logos4" / "Data",
        ]
    else:  # Linux
        home = Path.home()
        search_paths = [
            home / ".local" / "share" / "Logos" / "Data",
        ]
    
    for path in search_paths:
        if path.exists():
            # Suche nach DigitalLibrary.db oder UserResourceManifest.db
            for db_name in ["DigitalLibrary.db", "UserResourceManifest.db"]:
                db_path = path / db_name
                if db_path.exists():
                    return db_path
    
    return None

# ============================================================
# BUGFIX INTEGRATION
# ============================================================

def apply_bugfix(db_path):
    """Wendet den Bugfix auf die Logos-Datenbank an"""
    
    print(f"📂 Datenbank gefunden: {db_path}")
    
    # Lese die Bugfix-Dateien
    if not PYTHON_HEREDOC_FILE.exists():
        print(f"❌ ERROR: {PYTHON_HEREDOC_FILE} no encontrado!")
        return False
    
    if not SCRIPT_FILE.exists():
        print(f"❌ ERROR: {SCRIPT_FILE} no encontrado!")
        return False
    
    with open(PYTHON_HEREDOC_FILE, 'r', encoding='utf-8') as f:
        python_code = f.read()
    
    with open(SCRIPT_FILE, 'r', encoding='utf-8') as f:
        script_content = f.read()
    
    print("✓ Archivos de bugfix cargados")
    
    # Verbinde mit der Datenbank
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 1. Füge Python Heredoc ein (falls Table existiert)
        print("\n[1/3] Insertando Python Heredoc...")
        
        # Prüfe ob die Tabelle existiert
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='PythonHeredocs'")
        if cursor.fetchone():
            cursor.execute("""
                INSERT OR REPLACE INTO PythonHeredocs (Name, Code, Description)
                VALUES (?, ?, ?)
            """, (
                "spanish_bible_check",
                python_code,
                "Bugfix: Detecta si el usuario tiene una Biblia española y muestra aviso"
            ))
            print("   ✓ Python Heredoc insertado")
        else:
            print("   ⚠ Tabla PythonHeredocs no encontrada - se omite")
        
        # 2. Aktualisiere oder füge Skript ein
        print("\n[2/3] Actualizando Script de versículo del día...")
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='Scripts'")
        if cursor.fetchone():
            cursor.execute("""
                INSERT OR REPLACE INTO Scripts (Name, Content, Language)
                VALUES (?, ?, ?)
            """, (
                "Spanish_DailyVerse_Fixed",
                script_content,
                "es"
            ))
            print("   ✓ Script actualizado")
        else:
            print("   ⚠ Tabla Scripts no encontrada - se omite")
        
        # 3. Commit
        print("\n[3/3] Guardando cambios...")
        conn.commit()
        print("   ✓ Cambios guardados")
        
        return True
        
    except sqlite3.Error as e:
        print(f"\n❌ ERROR de base de datos: {e}")
        conn.rollback()
        return False
    
    finally:
        conn.close()

# ============================================================
# MAIN
# ============================================================

def main():
    # Prüfe ob Bugfix-Dateien existieren
    if not BUGFIX_DIR.exists():
        print(f"❌ ERROR: Directorio de bugfix no encontrado: {BUGFIX_DIR}")
        print("   Asegúrese de ejecutar este script desde el directorio ES/")
        input("\nPresione ENTER para salir...")
        sys.exit(1)
    
    # Finde Logos-Datenbank
    print("🔍 Buscando base de datos de Logos...")
    db_path = find_logos_db()
    
    if not db_path:
        print("""
❌ No se encontró la base de datos de Logos.

INSTALACIÓN MANUAL:
1. Abra Logos
2. Vaya a Herramientas → Digital Library Manager
3. Importe manualmente los archivos de BUGFIX-Spanish-Bible-Hint/
   - python_heredoc.py (como Python Heredoc)
   - Skript (como Script)

Consulte SCHNELLANLEITUNG.txt para instrucciones detalladas.
""")
        input("\nPresione ENTER para salir...")
        sys.exit(1)
    
    # Wende Bugfix an
    print("\n🔧 Aplicando bugfix...")
    success = apply_bugfix(db_path)
    
    if success:
        print("""
╔═══════════════════════════════════════════════════════════════╗
║  ✅ BUGFIX APLICADO EXITOSAMENTE                              ║
╚═══════════════════════════════════════════════════════════════╝

El bugfix ha sido instalado correctamente.

PRÓXIMOS PASOS:
1. Reinicie Logos
2. Abra el panel de versículo del día español
3. Si no tiene una Biblia española, verá un aviso amarillo

NOTA: Si el aviso no aparece, consulte FEHLERBEHEBUNG.md
para solución de problemas.
""")
    else:
        print("""
╔═══════════════════════════════════════════════════════════════╗
║  ⚠️  INSTALACIÓN PARCIAL                                      ║
╚═══════════════════════════════════════════════════════════════╝

Algunos componentes no pudieron instalarse automáticamente.
Consulte SCHNELLANLEITUNG.txt para instalación manual.
""")
    
    input("\nPresione ENTER para salir...")

if __name__ == "__main__":
    main()

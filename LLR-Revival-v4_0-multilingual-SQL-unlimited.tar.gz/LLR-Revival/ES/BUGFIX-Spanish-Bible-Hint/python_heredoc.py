import logging
import json

# Funktion um zu prüfen ob eine spanische Bibel verfügbar ist
def check_spanish_bible_available():
    """
    Prüft ob der Benutzer mindestens eine spanische Bibel in seiner Bibliothek hat.
    Gibt True zurück wenn eine spanische Bibel gefunden wurde, sonst False.
    """
    try:
        # Hole alle Bibeln aus der Bibliothek des Benutzers
        bibles = Application.GetResources("Bible")
        
        # Liste der gängigen spanischen Bibelressourcen
        spanish_bible_ids = [
            "RVR60",      # Reina-Valera 1960
            "RVR95",      # Reina-Valera 1995
            "RVR1977",    # Reina-Valera 1977
            "NVI",        # Nueva Versión Internacional
            "LBLA",       # La Biblia de las Américas
            "DHH",        # Dios Habla Hoy
            "TLA",        # Traducción en lenguaje actual
            "RVC",        # Reina Valera Contemporánea
            "NBV",        # Nueva Biblia Viva
            "PDT",        # Palabra de Dios para Todos (Spanisch)
            "BLP",        # La Palabra (España)
            "CST",        # Castilian
            "NBLH",       # Nueva Biblia Latinoamericana de Hoy
        ]
        
        # Durchsuche die Bibeln nach spanischen Versionen
        for bible in bibles:
            resource_id = bible.ResourceId
            # Prüfe ob die Ressource eine der spanischen Bibeln ist
            for spanish_id in spanish_bible_ids:
                if spanish_id.lower() in resource_id.lower():
                    logging.info(f"Spanische Bibel gefunden: {resource_id}")
                    return True
        
        logging.warning("Keine spanische Bibel in der Bibliothek gefunden")
        return False
        
    except Exception as e:
        logging.error(f"Fehler beim Prüfen der spanischen Bibeln: {str(e)}")
        return False

# Registriere die Hint-Funktion
def spanish_bible_hint():
    """
    Zeigt einen PROMINENTEN Hinweis an, wenn keine spanische Bibel verfügbar ist.
    """
    if not check_spanish_bible_available():
        return """
        <div class='spanish-bible-warning'>
            <button class='spanish-bible-warning-close' onclick='this.parentElement.style.display="none"' title='Cerrar'>✕</button>
            <h4>⚠️ Biblia en español no encontrada</h4>
            <p>
                <strong>Logos ha abierto el versículo en la Biblia predeterminada</strong> porque no se encontró 
                una Biblia en español configurada.
            </p>
            <p>
                <strong>Para solucionarlo:</strong> Vaya a <strong>Herramientas → Opciones → Biblias preferidas</strong> 
                y seleccione su Biblia en español (por ejemplo: Reina-Valera 1960).
            </p>
            <p>
                <em>Si aún no tiene una Biblia española, puede adquirir la 
                <a href="https://www.logos.com/es/product/27297/reina-valera-1960" target="_blank">Reina-Valera 1960</a> 
                en la tienda de Logos.</em>
            </p>
        </div>
        """
    return ""

# Registriere die Funktion in Logos
Application.RegisterHintFunction("spanish_bible_hint", spanish_bible_hint)
